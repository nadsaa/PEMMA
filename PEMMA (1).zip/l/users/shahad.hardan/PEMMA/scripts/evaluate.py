#!/usr/bin/env python
"""
Evaluation script that uses the exact same code path as the training script,
but only runs validation without training.
"""

import os
import sys
import argparse
import yaml
import json
from pathlib import Path

import torch
import torch.distributed as dist
import numpy as np
import random
from peft import get_peft_model, LoraConfig, TaskType, PeftModel

# Add the project root to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.dataset import load_strategy_config, get_phase_dataloaders
from src.models.model import create_model
from src.trainers.trainer import Trainer, get_trainer

from monai.utils import set_determinism

def set_seed(seed: int = 42) -> None:
    """
    Set random seed for reproducibility.
    
    Args:
        seed: Random seed
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    set_determinism(seed=seed)


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate SwinUNETR model using training pipeline")
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to the configuration file",
    )
    parser.add_argument(
        "--strategy",
        type=str,
        required=False,
        help="Path to the training strategy configuration file (for HECKTOR dataset)",
    )
    parser.add_argument(
        "--phase",
        type=str,
        required=True,
        choices=["multimodal_adaptation", "continual_learning_task1", "continual_learning_task2"],
        help="Phase of the training strategy to use (for HECKTOR dataset)",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        help="Path to the checkpoint file for resuming training",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./eval_outputs",
        help="Path to the output directory",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )
    parser.add_argument(
        "--peft-method",
        type=str,
        default="direct",
        choices=["direct", "lora", "dora"],
        help="PEFT method to use: 'direct' for directly unfreezing layers, 'lora' for LoRA, or 'dora' for DoRA",
    )
    parser.add_argument(
        "--peft-checkpoint",
        type=str,
        default=None,
        help="Path to the PEFT adapter checkpoint directory for evaluation",
    )
    parser.add_argument(
        "--mode",
        type=str,
        default=None,
        help="Mode to use for evaluation (ct, pet, or ctpet)",
    )
    parser.add_argument(
        "--gpu",
        default=None,
        type=int,
        help="GPU id to use. If None, will use all available GPUs with --distributed",
    )
    return parser.parse_args()


class VisionModelWrapper(torch.nn.Module):
    def __init__(self, model, peft_config=None):
        super().__init__()
        # Check if model is already a PeftModel
        if hasattr(model, 'base_model') and hasattr(model, 'active_adapter'):
            # Model is already a PeftModel, use it directly
            self.peft_model = model
        else:
            # Model is a base model, apply PEFT to it
            self.peft_model = get_peft_model(model, peft_config)
            
        # Initialize with base model's mode
        base_model = getattr(self.peft_model, 'base_model', self.peft_model)
        self._mode = base_model.mode if hasattr(base_model, 'mode') else "ctpet"
        
        # Call the mode setter to propagate the initial mode
        self.mode = self._mode
        
    def _propagate_mode_recursively(self, module, mode):
        """Recursively set mode on all submodules that have a mode attribute."""
        if hasattr(module, 'mode'):
            module.mode = mode
            # Debug output
            print(f"Set mode to {mode} on {type(module).__name__}")
            
        # Recursively process all children that are not parameters
        for child_name, child in module.named_children():
            self._propagate_mode_recursively(child, mode)
            
    @property
    def mode(self):
        return self._mode
        
    @mode.setter
    def mode(self, value):
        self._mode = value
        
        # Propagate to base_model first
        if hasattr(self.peft_model, 'base_model'):
            if hasattr(self.peft_model.base_model, 'mode'):
                self.peft_model.base_model.mode = value
                print(f"Set base_model.mode to {value}")
                
            # Legacy way - propagate specifically to swinViT
            if hasattr(self.peft_model.base_model, 'swinViT') and hasattr(self.peft_model.base_model.swinViT, 'mode'):
                self.peft_model.base_model.swinViT.mode = value
                print(f"Set base_model.swinViT.mode to {value}")
                
            # Enhanced mode propagation - recursive propagation to all submodules
            self._propagate_mode_recursively(self.peft_model.base_model, value)
        
        # Direct propagation to any module attributes that might have mode
        elif hasattr(self.peft_model, 'mode'):
            self.peft_model.mode = value
            self._propagate_mode_recursively(self.peft_model, value)
        
    def forward(self, x):
        # Enforce mode setting before each forward pass
        self.mode = self._mode
        
        # For debugging, print mode values
        print(f"Forward pass with mode: {self._mode}")
        
        # Check key model components for mode setting
        if hasattr(self.peft_model.base_model, 'mode'):
            print(f"  base_model mode: {self.peft_model.base_model.mode}")
        if hasattr(self.peft_model.base_model, 'swinViT') and hasattr(self.peft_model.base_model.swinViT, 'mode'):
            print(f"  swinViT mode: {self.peft_model.base_model.swinViT.mode}")
            
        # Only pass the input tensor, avoiding input_ids and other language model params
        return self.peft_model(x)
        
    def save_pretrained(self, path):
        # Pass through save_pretrained to the peft_model
        return self.peft_model.save_pretrained(path)
        
    def train(self, mode=True):
        # Make sure train mode is properly passed through
        self.peft_model.train(mode)
        return super().train(mode)
        
    def eval(self):
        # Make sure eval mode is properly passed through
        self.peft_model.eval()
        return super().eval()
        
    def parameters(self):
        # Return parameters from the PEFT model for the optimizer
        return self.peft_model.parameters()
        
    def named_parameters(self, *args, **kwargs):
        # Return named parameters from the PEFT model
        return self.peft_model.named_parameters(*args, **kwargs)


# Debug tools for examining model forward pass
class ModuleTypeCounter:
    """Helper class to count module types in a model."""
    def __init__(self):
        self.module_counts = {}
        
    def count(self, model):
        """Count the different types of modules in the model."""
        for name, module in model.named_modules():
            module_type = type(module).__name__
            if module_type in self.module_counts:
                self.module_counts[module_type] += 1
            else:
                self.module_counts[module_type] = 1
                
    def print_counts(self):
        """Print the module counts."""
        print("\nModule type counts:")
        for module_type, count in sorted(self.module_counts.items()):
            print(f"  {module_type}: {count}")

# Additional tools to examine model components
def examine_model(model):
    """Examine important components of the model."""
    # Count module types
    counter = ModuleTypeCounter()
    if hasattr(model, 'peft_model'):
        base_model = model.peft_model.base_model
        counter.count(base_model)
    else:
        counter.count(model)
    counter.print_counts()
    
    # Print out structure of the SwinViT component
    print("\nExamining SwinViT structure:")
    swin_vit = None
    if hasattr(model, 'peft_model') and hasattr(model.peft_model, 'base_model') and hasattr(model.peft_model.base_model, 'swinViT'):
        swin_vit = model.peft_model.base_model.swinViT
    elif hasattr(model, 'swinViT'):
        swin_vit = model.swinViT
    
    if swin_vit is not None:
        print(f"  SwinViT has mode attribute: {hasattr(swin_vit, 'mode')}")
        if hasattr(swin_vit, 'mode'):
            print(f"  Current SwinViT mode: {swin_vit.mode}")
        
        # Examine the patch embedding components
        if hasattr(swin_vit, 'patch_embed'):
            print(f"  Has CT patch_embed: True")
            print(f"  CT patch_embed type: {type(swin_vit.patch_embed).__name__}")
            
        if hasattr(swin_vit, 'patch_embed_pet'):
            print(f"  Has PET patch_embed_pet: True")
            print(f"  PET patch_embed_pet type: {type(swin_vit.patch_embed_pet).__name__}")
            
        # Check for fusion layers
        if hasattr(swin_vit, 'ctpet_proj'):
            print(f"  Has ctpet_proj: True")
            print(f"  ctpet_proj type: {type(swin_vit.ctpet_proj).__name__}")
        
        # Check for mode-specific adapters
        if hasattr(swin_vit, 'ct_adapter'):
            print(f"  Has ct_adapter: True")
            print(f"  ct_adapter type: {type(swin_vit.ct_adapter).__name__}")
            
        if hasattr(swin_vit, 'pet_adapter'):
            print(f"  Has pet_adapter: True") 
            print(f"  pet_adapter type: {type(swin_vit.pet_adapter).__name__}")
        
        # Check methods for handling mode
        print(f"\nExamining SwinViT forward pass to verify mode handling:")
        if hasattr(swin_vit, 'forward'):
            import inspect
            # Get the source code of the forward method
            try:
                forward_source = inspect.getsource(swin_vit.forward)
                print("SwinViT forward method contains mode-specific branching:")
                
                # Look for clues about mode handling
                mode_checks = [
                    line for line in forward_source.split('\n') 
                    if 'mode' in line and ('if' in line or 'elif' in line)
                ]
                
                for line in mode_checks:
                    print(f"  {line.strip()}")
            except:
                print("Could not retrieve source code for SwinViT forward method.")
    else:
        print("  Could not find SwinViT component in the model.")


def main():
    args = parse_args()
    
    # Set random seed
    set_seed(args.seed)
    
    # Set device
    device = torch.device(f"cuda:{args.gpu}" if args.gpu is not None else "cuda")
    
    # Load configuration
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Determine if we're using the HECKTOR dataset with strategy
    using_hecktor_strategy = args.strategy is not None and args.phase is not None
    
    # Get dataloaders
    if using_hecktor_strategy:
        print(f"Using HECKTOR dataset with strategy phase: {args.phase}")
        
        # Load strategy configuration
        strategy_config = load_strategy_config(args.strategy)
        phase_config = strategy_config["phases"][args.phase]
        
        # Update config with phase-specific settings
        config["data"]["modalities"] = phase_config["modalities"]
        
        # Get dataloaders for the specified phase
        dataloaders = get_phase_dataloaders(
            data_dir=config["data"]["data_dir"],
            config_path=args.strategy,
            phase=args.phase,
            batch_size=config["training"]["batch_size"],
            num_workers=config["data"]["num_workers"],
            cache_rate=config["data"]["cache_rate"],
            seed=args.seed,
            num_samples=config["data"].get("num_samples", 4),
        )
    else:
        raise ValueError("Only HECKTOR dataset with strategy is supported for evaluation")
    
    val_loader = dataloaders["val"]
    
    # Create model
    model = create_model(
        model_name=config["model"]["name"],
        in_channels=config["model"]["in_channels"],
        out_channels=config["model"]["out_channels"],
        img_size=config["model"]["img_size"],
        feature_size=config["model"]["feature_size"],
        use_checkpoint=config["model"]["use_checkpoint"],
        spatial_dims=config["model"].get("spatial_dims", 3),
        depths=config["model"].get("depths", (2, 2, 2, 2)),
        num_heads=config["model"].get("num_heads", (3, 6, 12, 24)),
        norm_name=config["model"].get("norm_name", "instance"),
        drop_rate=config["model"].get("drop_rate", 0.0),
        attn_drop_rate=config["model"].get("attn_drop_rate", 0.0),
        dropout_path_rate=config["model"].get("dropout_path_rate", 0.0),
        normalize=config["model"].get("normalize", True),
        encoding=config["model"].get("encoding", "rand_embedding"),
        mode=args.mode,
    )
    
    # Add debug hook to monitor mode propagation
    def debug_forward_hook(module, input, output):
        if hasattr(module, 'mode'):
            print(f"Module {type(module).__name__} mode: {module.mode}")
        return output

    # Register hooks for monitoring internal activations
    def register_debug_hooks(model):
        print(f"Registering debug hooks for model...")
        hooks = []
        
        # Register hook for top-level model
        if hasattr(model, 'mode'):
            hook = model.register_forward_hook(debug_forward_hook)
            hooks.append(hook)
        
        # Register hook for SwinViT if present
        if hasattr(model, 'swinViT'):
            hook = model.swinViT.register_forward_hook(debug_forward_hook)
            hooks.append(hook)
            
            # Also add hooks for patch embedding and other components
            if hasattr(model.swinViT, 'patch_embed'):
                hook = model.swinViT.patch_embed.register_forward_hook(
                    lambda module, input, output: print(f"CT patch_embed activated"))
                hooks.append(hook)
                
            if hasattr(model.swinViT, 'patch_embed_pet'):
                hook = model.swinViT.patch_embed_pet.register_forward_hook(
                    lambda module, input, output: print(f"PET patch_embed activated"))
                hooks.append(hook)
                
            if hasattr(model.swinViT, 'ctpet_proj'):
                hook = model.swinViT.ctpet_proj.register_forward_hook(
                    lambda module, input, output: print(f"CTPET projection activated"))
                hooks.append(hook)
            
        if hasattr(model, 'conv_trans'):
            for i, layer in enumerate(model.conv_trans):
                if hasattr(layer, 'mode'):
                    hook = layer.register_forward_hook(
                        lambda module, input, output, idx=i: print(f"Conv trans layer {idx} mode: {module.mode}"))
                    hooks.append(hook)
        
        return hooks

    # Move model to device
    model = model.to(device)

    # Print model architecture
    print("\nModel Architecture:")
    model_structure = str(model)
    print(model_structure)
    
    # Load checkpoint - we're directly using the code from finetune.py here
    if args.checkpoint:
        print(f"Loading checkpoint from {args.checkpoint}")
        checkpoint = torch.load(args.checkpoint, weights_only=False)
        
        # Handle PEFT-style checkpoints by removing prefixes
        if "model_state_dict" in checkpoint:
            state_dict = checkpoint["model_state_dict"]
            
            # Check if this is a PEFT-style checkpoint with prefixed keys
            if any(k.startswith("peft_model.") for k in state_dict.keys()):
                print("Detected PEFT-style checkpoint with prefixed keys. Remapping keys...")
                
                # Remap keys by removing the PEFT prefixes
                new_state_dict = {}
                for key, value in state_dict.items():
                    if key.startswith("peft_model.base_model.model."):
                        new_key = key.replace("peft_model.base_model.model.", "")
                        new_state_dict[new_key] = value
                    elif key.startswith("base_model.model."):  
                        new_key = key.replace("base_model.model.", "")
                        new_state_dict[new_key] = value
                    else:
                        # Keep other keys as-is
                        new_state_dict[key] = value
                
                print(f"Remapped {len(new_state_dict)} keys to remove PEFT prefixes")
                
                # Load with remapped keys
                model.load_state_dict(new_state_dict, strict=False)
            else:
                # Regular checkpoint
                model.load_state_dict(state_dict, strict=False)
                print("Loaded regular checkpoint without key remapping")
    
    # Check if we're loading a PEFT checkpoint (directly from finetune.py)
    if args.peft_checkpoint:
        from peft import PeftModel
        peft_checkpoint_path = Path(args.peft_checkpoint)
        
        # Try to find the adapter_config.json file
        if not (peft_checkpoint_path / "adapter_config.json").exists():
            # Check if it's a directory containing peft_model or peft_model_best
            if (peft_checkpoint_path / "peft_model_best" / "adapter_config.json").exists():
                peft_checkpoint_path = peft_checkpoint_path / "peft_model_best"
            elif (peft_checkpoint_path / "peft_model" / "adapter_config.json").exists():
                peft_checkpoint_path = peft_checkpoint_path / "peft_model"
        
        print(f"Loading PEFT model from {peft_checkpoint_path}")
        
        # We need to make sure we have a clean model (no PEFT prefixes) 
        # before applying PeftModel.from_pretrained()
        # This ensures we don't get nested PEFT adapters
        
        # Load the PEFT model from the checkpoint
        model = PeftModel.from_pretrained(
            model, 
            peft_checkpoint_path, 
            is_trainable=False,  # Not training here, just evaluating
            inference_mode=False  # Important to match training conditions
        )
        
        # Wrap the model to handle mode setting
        model = VisionModelWrapper(model)
        
        print(f"Successfully loaded PEFT model for evaluation")
    
    # Print verbose information about the model for debugging
    print(f"Model: {config['model']['name']}")
    print(f"Total parameters: {sum(p.numel() for p in model.parameters())}")
    
    # Run detailed model examination
    print("\n" + "=" * 80)
    print("DETAILED MODEL EXAMINATION")
    print("=" * 80)
    examine_model(model)
    print("=" * 80 + "\n")
    
    # Set model mode for evaluation
    if hasattr(model, "mode") and args.mode is not None:
        print(f"Setting model mode to: {args.mode}")
        model.mode = args.mode
        
        # Check if mode was properly set
        print(f"Checking mode propagation:")
        if hasattr(model, "mode"):
            print(f"  Top-level model mode: {model.mode}")
        if hasattr(model, "peft_model") and hasattr(model.peft_model, "base_model") and hasattr(model.peft_model.base_model, "mode"):
            print(f"  Base model mode: {model.peft_model.base_model.mode}")
        if hasattr(model, "peft_model") and hasattr(model.peft_model, "base_model") and hasattr(model.peft_model.base_model, "swinViT") and hasattr(model.peft_model.base_model.swinViT, "mode"):
            print(f"  SwinViT mode: {model.peft_model.base_model.swinViT.mode}")
    
    # Register debug hooks
    debug_hooks = register_debug_hooks(model if not hasattr(model, "peft_model") else model.peft_model.base_model)

    # Define a custom forward pass for testing mode propagation
    def test_mode_propagation(model, mode):
        print(f"\nTesting mode propagation with mode: {mode}")
        # Set model mode
        original_mode = None
        if hasattr(model, "mode"):
            original_mode = model.mode
            model.mode = mode
        
        # Create a dummy input tensor
        batch_size = 1
        channels = 2  # Adjust based on your model
        dummy_input = torch.randn(batch_size, channels, 96, 96, 96).to(device)
        
        # Run forward pass with dummy input
        with torch.no_grad():
            try:
                outputs = model(dummy_input)
                print(f"Forward pass successful with mode: {mode}")
            except Exception as e:
                print(f"Error during forward pass with mode {mode}: {str(e)}")
        
        # Restore original mode
        if original_mode is not None:
            model.mode = original_mode

    # Test mode propagation for all three modes
    for test_mode in ["ctpet", "ct", "pet"]:
        test_mode_propagation(model, test_mode)

    # Debug PEFT adapter weights
    if hasattr(model, "peft_model"):
        print("\nChecking PEFT adapter weights:")
        base_model = model.peft_model.base_model
        
        # Look for LoRA parameters
        lora_params = []
        adapter_params = []
        for name, param in model.named_parameters():
            if 'lora_' in name:
                lora_params.append((name, param.shape, torch.norm(param).item()))
            if 'adapter' in name:
                adapter_params.append((name, param.shape, torch.norm(param).item()))
        
        print(f"Found {len(lora_params)} LoRA parameters:")
        for name, shape, norm in lora_params[:10]:  # Show first 10
            print(f"  {name}: {shape}, norm={norm:.6f}")
        if len(lora_params) > 10:
            print(f"  ... and {len(lora_params) - 10} more")
        
        print(f"\nFound {len(adapter_params)} adapter parameters:")
        for name, shape, norm in adapter_params[:10]:  # Show first 10
            print(f"  {name}: {shape}, norm={norm:.6f}")
        if len(adapter_params) > 10:
            print(f"  ... and {len(adapter_params) - 10} more")

    # Update config for evaluation
    config["training"]["use_wandb"] = False
    config["training"]["distributed"] = False
    config["training"]["rank"] = 0
    config["training"]["world_size"] = 1
    config["training"]["device"] = device
    config["training"]["val_mode"] = args.mode
    config["training"]["batch_size"] = 1
    
    # Create trainer using exactly the same factory function as in training
    from src.trainers.trainer import get_trainer
    trainer = get_trainer(
        model=model,
        train_loader=dataloaders["train"],  # We provide train_loader but won't use it
        val_loader=val_loader,
        config=config["training"],
    )

    # Add another layer of tracking within the trainer
    original_validate = trainer.validate

    def patched_validate():
        print("\nRunning patched validate method...")
        print(f"Current model mode: {model.mode if hasattr(model, 'mode') else 'unknown'}")
        
        # Force model to evaluation mode
        model.eval()
        print(f"Model training mode: {model.training}")
        
        # Create a custom validation function that evaluates only the first batch
        device = model.device if hasattr(model, "device") else next(model.parameters()).device
        
        print("\n" + "=" * 80)
        print("RUNNING VALIDATION ON FIRST BATCH ONLY")
        print("=" * 80)
        
        # Process first batch from the validation loader
        try:
            # Get a single batch
            batch_data = next(iter(val_loader))
            
            # Print batch details
            print(f"Batch details:")
            print(f"  Image shape: {batch_data['image'].shape}")
            print(f"  Label shape: {batch_data['label'].shape}")
            if 'patient_id' in batch_data:
                print(f"  Patient IDs: {batch_data['patient_id']}")
            
            # Move to device
            inputs, labels = batch_data["image"].to(device), batch_data["label"].to(device)
            
            print(f"Input tensor details:")
            print(f"  Shape: {inputs.shape}")
            print(f"  Value range: [{inputs.min().item():.4f}, {inputs.max().item():.4f}]")
            print(f"  Mean: {inputs.mean().item():.4f}")
            print(f"  Std: {inputs.std().item():.4f}")
            
            print(f"Label tensor details:")
            print(f"  Shape: {labels.shape}")
            print(f"  Unique values: {torch.unique(labels).cpu().numpy()}")
            print(f"  Class counts: {[(i, (labels == i).sum().item()) for i in torch.unique(labels).cpu().numpy()]}")
            
            # Perform inference
            print("\nPerforming inference on sample...")
            
            with torch.no_grad():
                # Record which components are activated during forward pass
                print("\nForward pass activations:")
                outputs = model(inputs)
                print("Forward pass completed successfully!")
                
                # Analyze the output
                print(f"\nOutput tensor details:")
                print(f"  Shape: {outputs.shape}")
                print(f"  Value range: [{outputs.min().item():.4f}, {outputs.max().item():.4f}]")
                print(f"  Mean: {outputs.mean().item():.4f}")
                print(f"  Std: {outputs.std().item():.4f}")
                
                # Check prediction by taking argmax
                preds = torch.argmax(outputs, dim=1)
                print(f"\nPrediction tensor details:")
                print(f"  Shape: {preds.shape}")
                print(f"  Unique values: {torch.unique(preds).cpu().numpy()}")
                print(f"  Class counts: {[(i, (preds == i).sum().item()) for i in torch.unique(preds).cpu().numpy()]}")
            
            print("\nSingle batch validation completed successfully!")
            print("=" * 80)
            
            # Fall back to the original validation method to get metrics
            # (we keep running the full validation to get complete metrics)
            print("\nContinuing with full validation set for metrics calculation...")
            return original_validate()
            
        except Exception as e:
            print(f"Error during single batch validation: {str(e)}")
            import traceback
            traceback.print_exc()
            return {} # Return empty metrics if validation fails

    trainer.validate = patched_validate

    # Set output directory
    trainer.save_dir = output_dir

    # Run validation
    print(f"Running validation on {args.phase} with mode {args.mode}...")
    metrics = trainer.validate()

    # Clean up hooks
    for hook in debug_hooks:
        hook.remove()

    # Print results in the same format as in the logs
    print("\n" + "=" * 80)
    print(f"Evaluation Results for {args.phase} with model from {args.checkpoint}")
    if args.peft_checkpoint:
        print(f"PEFT checkpoint: {args.peft_checkpoint}")
    print("=" * 80)
    
    if "ctpet_dice" in metrics:
        print(f"CT+PET Mode - Dice: {metrics['ctpet_dice']:.4f}, "
              f"Tumor: {metrics['ctpet_tumor_dice']:.4f}, "
              f"Lymph: {metrics['ctpet_lymph_node_dice']:.4f}, "
              f"Agg GTVp: {metrics['ctpet_agg_dice_gtvp']:.4f}, "
              f"Agg GTVn: {metrics['ctpet_agg_dice_gtvn']:.4f}, "
              f"Agg Mean: {metrics['ctpet_agg_dice_mean']:.4f}")
    
    if "ct_dice" in metrics:
        print(f"CT Mode - Dice: {metrics['ct_dice']:.4f}, "
              f"Tumor: {metrics['ct_tumor_dice']:.4f}, "
              f"Lymph: {metrics['ct_lymph_node_dice']:.4f}, "
              f"Agg GTVp: {metrics['ct_agg_dice_gtvp']:.4f}, "
              f"Agg GTVn: {metrics['ct_agg_dice_gtvn']:.4f}, "
              f"Agg Mean: {metrics['ct_agg_dice_mean']:.4f}")
    
    if "pet_dice" in metrics:
        print(f"PET Mode - Dice: {metrics['pet_dice']:.4f}, "
              f"Tumor: {metrics['pet_tumor_dice']:.4f}, "
              f"Lymph: {metrics['pet_lymph_node_dice']:.4f}, "
              f"Agg GTVp: {metrics['pet_agg_dice_gtvp']:.4f}, "
              f"Agg GTVn: {metrics['pet_agg_dice_gtvn']:.4f}, "
              f"Agg Mean: {metrics['pet_agg_dice_mean']:.4f}")
    
    print("=" * 80)
    
    # Save results to file
    results_file = output_dir / f"eval_results_{args.phase}_{args.mode}.json"
    with open(results_file, "w") as f:
        json.dump(metrics, f, indent=2)
    
    print(f"Results saved to {results_file}")


if __name__ == "__main__":
    main()
