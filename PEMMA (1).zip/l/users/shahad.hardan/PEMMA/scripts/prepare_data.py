#!/usr/bin/env python
"""
Data preparation script for SwinUNETR model.
"""

import os
import sys
import argparse
import yaml
import shutil
import numpy as np
from pathlib import Path
from tqdm import tqdm
from sklearn.model_selection import train_test_split

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import nibabel as nib
import SimpleITK as sitk
from monai.transforms import (
    LoadImage, 
    SaveImage, 
    Orientation, 
    Spacing, 
    NormalizeIntensity,
    Resize,
)


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Prepare data for SwinUNETR model")
    parser.add_argument(
        "--config", type=str, required=True, help="Path to config file"
    )
    parser.add_argument(
        "--input-dir", type=str, required=True, help="Path to input directory"
    )
    parser.add_argument(
        "--output-dir", type=str, default="./data", help="Path to output directory"
    )
    parser.add_argument(
        "--modality", type=str, default="ct", choices=["ct", "pet"], help="Modality to process"
    )
    parser.add_argument(
        "--test-size", type=float, default=0.2, help="Test set size"
    )
    parser.add_argument(
        "--val-size", type=float, default=0.2, help="Validation set size (from train set)"
    )
    parser.add_argument(
        "--seed", type=int, default=42, help="Random seed"
    )
    return parser.parse_args()


def process_case(
    image_path: Path,
    label_path: Path,
    output_dir: Path,
    case_id: str,
    target_spacing: list,
    orientation: str,
):
    """
    Process a single case.
    
    Args:
        image_path: Path to image file
        label_path: Path to label file
        output_dir: Path to output directory
        case_id: Case ID
        target_spacing: Target spacing
        orientation: Target orientation
    """
    # Create output directory
    case_dir = output_dir / case_id
    case_dir.mkdir(parents=True, exist_ok=True)
    
    # Load image and label
    image_loader = LoadImage(image_only=False)
    label_loader = LoadImage(image_only=False)
    
    image, image_meta = image_loader(image_path)
    label, label_meta = label_loader(label_path)
    
    # Preprocess image
    # Orientation
    orientation_transform = Orientation(axcodes=orientation)
    image = orientation_transform(image)
    label = orientation_transform(label)
    
    # Spacing
    spacing_transform = Spacing(pixdim=target_spacing)
    image = spacing_transform(image)
    label = spacing_transform(label)
    
    # Normalize image
    normalize_transform = NormalizeIntensity()
    image = normalize_transform(image)
    
    # Save processed image and label
    image_saver = SaveImage(output_dir=str(case_dir), output_postfix="", output_ext=".nii.gz", output_dtype=np.float32)
    label_saver = SaveImage(output_dir=str(case_dir), output_postfix="", output_ext=".nii.gz", output_dtype=np.int32)
    
    image_saver(image, meta_data={"filename_or_obj": "image"})
    label_saver(label, meta_data={"filename_or_obj": "label"})


def main():
    """Main function."""
    # Parse arguments
    args = parse_args()
    
    # Load config
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)
    
    # Get data config
    data_config = config.get("data", {})
    target_spacing = data_config.get("target_spacing", [1.0, 1.0, 1.0])
    orientation = data_config.get("orientation", "RAS")
    
    # Create output directories
    output_dir = Path(args.output_dir)
    modality_dir = output_dir / args.modality
    train_dir = modality_dir / "train"
    val_dir = modality_dir / "val"
    test_dir = modality_dir / "test"
    
    for dir_path in [train_dir, val_dir, test_dir]:
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Find all cases in input directory
    input_dir = Path(args.input_dir)
    
    # This is a placeholder implementation
    # In a real scenario, you would need to adapt this to your specific data organization
    
    # Example: Assuming input_dir contains subdirectories for each case
    # with image.nii.gz and label.nii.gz files
    case_dirs = [d for d in input_dir.iterdir() if d.is_dir()]
    
    # Split cases into train, validation, and test sets
    train_val_dirs, test_dirs = train_test_split(
        case_dirs, 
        test_size=args.test_size, 
        random_state=args.seed
    )
    
    train_dirs, val_dirs = train_test_split(
        train_val_dirs, 
        test_size=args.val_size, 
        random_state=args.seed
    )
    
    # Process cases
    print(f"Processing {len(train_dirs)} training cases...")
    for case_dir in tqdm(train_dirs):
        image_path = case_dir / "image.nii.gz"
        label_path = case_dir / "label.nii.gz"
        
        if image_path.exists() and label_path.exists():
            process_case(
                image_path=image_path,
                label_path=label_path,
                output_dir=train_dir,
                case_id=case_dir.name,
                target_spacing=target_spacing,
                orientation=orientation,
            )
    
    print(f"Processing {len(val_dirs)} validation cases...")
    for case_dir in tqdm(val_dirs):
        image_path = case_dir / "image.nii.gz"
        label_path = case_dir / "label.nii.gz"
        
        if image_path.exists() and label_path.exists():
            process_case(
                image_path=image_path,
                label_path=label_path,
                output_dir=val_dir,
                case_id=case_dir.name,
                target_spacing=target_spacing,
                orientation=orientation,
            )
    
    print(f"Processing {len(test_dirs)} test cases...")
    for case_dir in tqdm(test_dirs):
        image_path = case_dir / "image.nii.gz"
        label_path = case_dir / "label.nii.gz"
        
        if image_path.exists() and label_path.exists():
            process_case(
                image_path=image_path,
                label_path=label_path,
                output_dir=test_dir,
                case_id=case_dir.name,
                target_spacing=target_spacing,
                orientation=orientation,
            )
    
    print(f"Data preparation completed. Processed data saved to {modality_dir}")


if __name__ == "__main__":
    main() 