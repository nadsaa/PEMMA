#!/usr/bin/env python
"""
Utility script to extract PEFT adapters from a checkpoint.
This can be useful for extracting LoRA weights from a checkpoint where
they're embedded with the full model.
"""

import os
import sys
import argparse
import torch
import json
from pathlib import Path
from safetensors.torch import save_file


def parse_args():
    parser = argparse.ArgumentParser(description='Extract PEFT adapter weights from a checkpoint')
    parser.add_argument('--checkpoint', type=str, required=True, help='Path to the checkpoint file')
    parser.add_argument('--output-dir', type=str, help='Directory to save the extracted PEFT adapter')
    parser.add_argument('--list-keys', action='store_true', help='List all keys in the checkpoint')
    parser.add_argument('--only-lora', action='store_true', help='Extract only LoRA weights')
    return parser.parse_args()


def main():
    args = parse_args()
    checkpoint_path = Path(args.checkpoint)
    
    # Load the checkpoint
    try:
        print(f"Loading checkpoint from {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location="cpu")
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
        sys.exit(1)
    
    # Check if checkpoint contains model_state_dict
    if "model_state_dict" not in checkpoint:
        print("Error: Checkpoint does not contain model_state_dict")
        print(f"Keys in checkpoint: {list(checkpoint.keys())}")
        sys.exit(1)
    
    # Get the model state dict
    model_state_dict = checkpoint["model_state_dict"]
    
    # If list-keys is specified, list all keys in the checkpoint
    if args.list_keys:
        print("Keys in model_state_dict:")
        for key in sorted(model_state_dict.keys()):
            print(f"  {key}")
        print("\nTo extract PEFT adapters, run without --list-keys")
        sys.exit(0)
    
    # Set the output directory
    if args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        # Default to a subdirectory of the checkpoint directory
        output_dir = checkpoint_path.parent / "extracted_peft_model"
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    print(f"Extracting PEFT adapter to {output_dir}")
    
    # Initialize a dictionary to store LoRA weights
    lora_state_dict = {}
    
    # Check if this is a PEFT model (has base_model prefix)
    is_peft_model = any(key.startswith("base_model.") for key in model_state_dict.keys())
    
    # Keep track of target modules and modules to save
    target_modules = set()
    modules_to_save = set()
    
    # Process keys
    for key, value in model_state_dict.items():
        # If this is a PEFT model, extract PEFT weights
        if is_peft_model:
            # Only keep keys with base_model. prefix, which is how PEFT models are stored
            if key.startswith("base_model."):
                # Extract component after base_model.
                new_key = key[len("base_model."):]
                lora_state_dict[new_key] = value
                
                # Try to determine target modules from key names
                if ".lora_" in new_key:
                    module_name = new_key.split(".lora_")[0]
                    target_modules.add(module_name)
                
                # Extract modules_to_save
                if not new_key.startswith("lora_"):
                    module_name = new_key.split(".")[0]
                    modules_to_save.add(module_name)
        
        # If this is a regular model with LoRA weights
        elif args.only_lora:
            # Only extract keys with lora_A or lora_B
            if "lora_A" in key or "lora_B" in key:
                lora_state_dict[key] = value
                
                # Try to determine target modules from key names
                if ".lora_" in key:
                    module_name = key.split(".lora_")[0]
                    target_modules.add(module_name)
        
        # If extracting all weights
        else:
            lora_state_dict[key] = value
    
    # Construct adapter config if sufficient information is available
    if target_modules:
        adapter_config = {
            "base_model_name_or_path": "extracted_model",
            "inference_mode": False,
            "lora_alpha": 16,  # Default value
            "lora_dropout": 0.1,  # Default value
            "r": 8,  # Default value
            "target_modules": list(target_modules),
            "task_type": "FEATURE_EXTRACTION"
        }
        
        if modules_to_save:
            adapter_config["modules_to_save"] = list(modules_to_save)
        
        # Save adapter config
        with open(output_dir / "adapter_config.json", "w") as f:
            json.dump(adapter_config, f, indent=2)
        print(f"Saved adapter_config.json with target_modules: {list(target_modules)}")
    
    # Save weights
    if lora_state_dict:
        save_file(lora_state_dict, output_dir / "adapter_model.safetensors")
        print(f"Saved adapter weights with {len(lora_state_dict)} parameters")
        
        # Write a README file
        with open(output_dir / "README.md", "w") as f:
            f.write(f"# Extracted PEFT Adapter\n\n")
            f.write(f"Extracted from: {checkpoint_path}\n\n")
            f.write(f"Number of adapter weights: {len(lora_state_dict)}\n\n")
            if target_modules:
                f.write(f"Target modules: {list(target_modules)}\n\n")
            if modules_to_save:
                f.write(f"Modules to save: {list(modules_to_save)}\n\n")
    else:
        print("No LoRA weights found in the checkpoint")


if __name__ == "__main__":
    main() 