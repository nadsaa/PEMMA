#!/usr/bin/env python
"""
Training script for SwinUNETR model.
"""

import os
import sys
import argparse
import yaml
import json
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
import numpy as np
import random
from torch.utils.tensorboard import SummaryWriter
from peft import get_peft_model, LoraConfig, TaskType, PeftModel

# Add the project root to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.dataset import load_strategy_config, get_phase_dataloaders
from src.models.model import create_model
from src.trainers.trainer import Trainer, get_trainer

from monai.utils import set_determinism

def set_seed(seed: int = 42) -> None:
    """
    Set random seed for reproducibility.
    
    Args:
        seed: Random seed
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    set_determinism(seed=seed)

# Create a wrapper class to handle the input_ids issue
class VisionModelWrapper(torch.nn.Module):
        def __init__(self, model, peft_config=None):
            super().__init__()
            # Check if model is already a PeftModel
            if hasattr(model, 'base_model') and hasattr(model, 'active_adapter'):
                # Model is already a PeftModel, use it directly
                self.peft_model = model
            else:
                # Model is a base model, apply PEFT to it
                print("Applying PEFT to base model")
                self.peft_model = get_peft_model(model, peft_config)
                self.peft_model.print_trainable_parameters()
                
            # Initialize with base model's mode
            base_model = getattr(self.peft_model, 'base_model', self.peft_model)
            self._mode = base_model.mode if hasattr(base_model, 'mode') else "ctpet"
            
        @property
        def mode(self):
            return self._mode
            
        @mode.setter
        def mode(self, value):
            self._mode = value
            # Propagate mode to base_model
            if hasattr(self.peft_model.base_model, 'mode'):
                self.peft_model.base_model.mode = value
            # Propagate mode to swinViT
            if hasattr(self.peft_model.base_model, 'swinViT') and hasattr(self.peft_model.base_model.swinViT, 'mode'):
                self.peft_model.base_model.swinViT.mode = value
            
        def forward(self, x):
            # Ensure mode is properly set before forward pass
            if hasattr(self.peft_model.base_model, 'mode'):
                self.peft_model.base_model.mode = self._mode
            if hasattr(self.peft_model.base_model, 'swinViT') and hasattr(self.peft_model.base_model.swinViT, 'mode'):
                self.peft_model.base_model.swinViT.mode = self._mode
                
            return self.peft_model(x)
            
        def save_pretrained(self, path):
            # Pass through save_pretrained to the peft_model
            return self.peft_model.save_pretrained(path)
            
        def train(self, mode=True):
            # Make sure train mode is properly passed through
            self.peft_model.train(mode)
            return super().train(mode)
            
        def eval(self):
            # Make sure eval mode is properly passed through
            self.peft_model.eval()
            return super().eval()
            
        def parameters(self):
            # Return parameters from the PEFT model for the optimizer
            return self.peft_model.parameters()
            
        def named_parameters(self, *args, **kwargs):
            # Return named parameters from the PEFT model
            return self.peft_model.named_parameters(*args, **kwargs)

def parse_args():
    parser = argparse.ArgumentParser(description="Train SwinUNETR model")
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to the configuration file",
    )
    parser.add_argument(
        "--mode",
        type=str,
        required=True,
        help="Base model mode (ct, pet, or ctpet) - defines which input modalities the model architecture supports. This is the fundamental capability of the model, regardless of what data you use for training.",
    )
    parser.add_argument(
        "--strategy",
        type=str,
        required=False,
        help="Path to the training strategy configuration file (for HECKTOR dataset)",
    )
    parser.add_argument(
        "--phase",
        type=str,
        required=True,
        choices=["multimodal_adaptation", "continual_learning_task1", "continual_learning_task2"],
        help="Phase of the training strategy to use (for HECKTOR dataset)",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        default=None,
        help="Path to the checkpoint file for resuming training",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./outputs",
        help="Path to the output directory",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )
    parser.add_argument(
        "--use-wandb",
        action="store_true",
        help="Whether to use Weights & Biases for logging",
    )
    parser.add_argument(
        "--wandb-project",
        type=str,
        default="pemma",
        help="Weights & Biases project name",
    )
    parser.add_argument(
        "--wandb-entity",
        type=str,
        default=None,
        help="Weights & Biases entity name",
    )
    parser.add_argument(
        "--distributed",
        action="store_true",
        help="Whether to use distributed training",
    )
    parser.add_argument(
        "--world-size",
        type=int,
        default=4,
        help="Number of processes for distributed training",
    )
    parser.add_argument(
        "--dist-url",
        default="tcp://localhost:23456",
        help="URL used to set up distributed training",
    )
    parser.add_argument(
        "--dist-backend",
        default="nccl",
        help="Distributed backend",
    )
    parser.add_argument(
        "--gpu",
        default=None,
        type=int,
        help="GPU id to use. If None, will use all available GPUs with --distributed",
    )
    parser.add_argument(
        "--rank",
        default=0,
        type=int,
        help="Node rank for distributed training",
    )
    parser.add_argument(
        "--peft-method",
        type=str,
        default="direct",
        choices=["direct", "lora", "dora"],
        help="PEFT method to use: 'direct' for directly unfreezing layers, 'lora' for LoRA, or 'dora' for DoRA",
    )
    parser.add_argument(
        "--lora-r",
        type=int,
        default=8,
        help="LoRA rank (r) parameter",
    )
    parser.add_argument(
        "--lora-alpha",
        type=int,
        default=16,
        help="LoRA alpha parameter",
    )
    parser.add_argument(
        "--lora-dropout",
        type=float,
        default=0.1,
        help="LoRA dropout parameter",
    )
    parser.add_argument(
        "--target-modules",
        type=str,
        default="attn.qkv,attn.proj,mlp.linear1,mlp.linear2",
        help="Comma-separated list of module names to target for fine-tuning (e.g., 'qkv,proj,linear1,linear2')"
    )
    parser.add_argument(
        "--unfreeze-modules",
        type=str,
        default="encoder1_pet,ctpet_proj,patch_embed_pet,pet_adapter,ct_adapter",
        help="Comma-separated list of module names that should not be frozen by default"
    )
    # Add training strategy arguments
    parser.add_argument(
        "--training-strategy",
        type=str,
        default="random",
        choices=["random", "fixed"],
        help="Strategy for mode selection during training ('random' or 'fixed')",
    )
    parser.add_argument(
        "--train-mode",
        type=str,
        default=None,
        help="Specific mode to use during training when using fixed training strategy (ct, pet, or ctpet). If not specified, defaults to the value of '--mode'. Used to train on a subset of modalities even if the model supports more.",
    )
    parser.add_argument(
        "--modes",
        type=str,
        default="ctpet,ct,pet",
        help="Comma-separated list of modes for random selection during training (e.g., 'ctpet,ct,pet'). Only used when training_strategy='random'.",
    )
    parser.add_argument(
        "--mode-weights",
        type=str,
        default="0.6,0.2,0.2",
        help="Comma-separated list of probability weights for random mode selection. These values should sum to 1 and match the number of modes in '--modes'. Only used when training_strategy='random'.",
    )
    parser.add_argument(
        "--val-mode",
        type=str,
        default="all",
        help="Mode for validation: 'all' (validate on all modes), 'same_as_train' (use training mode), or a specific mode (ct, pet, ctpet). This allows for flexible validation strategies independent of training mode.",
    )
    parser.add_argument(
        "--peft-checkpoint",
        type=str,
        default=None,
        help="Path to the PEFT adapter checkpoint directory for continual learning",
    )
    return parser.parse_args()


def setup_distributed(args):
    """
    Setup distributed training.
    
    Args:
        args: Command line arguments
    """
    if args.gpu is not None:
        # Single GPU training
        torch.cuda.set_device(args.gpu)
        args.device = torch.device(f"cuda:{args.gpu}")
        args.rank = 0
        args.world_size = 1
    else:
        # Multi-GPU training
        args.device = torch.device("cuda")
        if args.distributed:
            if args.dist_url == "env://" and args.rank == -1:
                args.rank = int(os.environ["RANK"])
            
            dist.init_process_group(
                backend=args.dist_backend,
                init_method=args.dist_url,
                world_size=args.world_size,
                rank=args.rank,
            )
            # Set the device to the local rank
            args.gpu = args.rank % torch.cuda.device_count()
            torch.cuda.set_device(args.gpu)
            args.device = torch.device(f"cuda:{args.gpu}")
            
            print(f"Initialized process group: rank {args.rank}, world_size {args.world_size}, device {args.device}")


def main_worker(gpu, args):
    """
    Main worker function for distributed training.
    
    Args:
        gpu: GPU ID
        args: Command line arguments
    """
    args.gpu = gpu
    
    # Setup distributed training if needed
    if args.distributed:
        args.rank = args.rank * torch.cuda.device_count() + gpu
        dist.init_process_group(
            backend=args.dist_backend,
            init_method=args.dist_url,
            world_size=args.world_size,
            rank=args.rank,
        )
        torch.cuda.set_device(args.gpu)
        args.device = torch.device(f"cuda:{args.gpu}")  # Set the device attribute
    else:
        # For non-distributed training, also set the device
        args.device = torch.device(f"cuda:{args.gpu}" if args.gpu is not None else "cuda")
    
    # Set random seed
    set_seed(args.seed + args.rank)  # Different seed for each process
    
    # Load configuration
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Create tensorboard writer (only for rank 0)
    writer = None
    if not args.distributed or args.rank == 0:
        writer = SummaryWriter(log_dir=str(output_dir / "logs"))
    
    # Determine if we're using the HECKTOR dataset with strategy
    using_hecktor_strategy = args.strategy is not None and args.phase is not None
    
    # Get dataloaders
    if using_hecktor_strategy:
        if not args.distributed or args.rank == 0:
            print(f"Using HECKTOR dataset with strategy phase: {args.phase}")
        
        # Load strategy configuration
        strategy_config = load_strategy_config(args.strategy)
        phase_config = strategy_config["phases"][args.phase]
        
        # Update config with phase-specific settings
        config["data"]["modalities"] = phase_config["modalities"]
        
        # Get dataloaders for the specified phase
        dataloaders = get_phase_dataloaders(
            data_dir=config["data"]["data_dir"],
            config_path=args.strategy,
            phase=args.phase,
            batch_size=config["training"]["batch_size"],
            num_workers=config["data"]["num_workers"],
            cache_rate=config["data"]["cache_rate"],
            seed=args.seed,
            num_samples=config["data"].get("num_samples", 4),  # Get from config or use default 4
        )
        
        # Add distributed samplers if using distributed training
        if args.distributed:
            train_sampler = DistributedSampler(dataloaders["train"].dataset)
            val_sampler = DistributedSampler(dataloaders["val"].dataset, shuffle=False)
            
            # Recreate dataloaders with distributed samplers
            from src.data.dataset import get_dataloader
            
            train_dataloader = get_dataloader(
                dataset=dataloaders["train"].dataset,
                batch_size=config["training"]["batch_size"],
                shuffle=False,  # Sampler handles shuffling
                num_workers=config["data"]["num_workers"],
                sampler=train_sampler,
                pin_memory=True,
            )
            
            val_dataloader = get_dataloader(
                dataset=dataloaders["val"].dataset,
                batch_size=config["training"]["batch_size"],
                shuffle=False,
                num_workers=config["data"]["num_workers"],
                sampler=val_sampler,
                pin_memory=True,
            )
            
            dataloaders = {
                "train": train_dataloader,
                "val": val_dataloader,
                "train_sampler": train_sampler,
                "val_sampler": val_sampler,
            }
    else:
        # Use the standard dataset preparation
        from src.data.dataset import prepare_datalist, get_dataset, get_dataloader
        
        # Prepare datalist using provided seed for data splitting
        datalist_dict = prepare_datalist(
            data_dir=config["data"]["data_dir"],
            centers=config["data"].get("centers", []),
            modalities=config["data"]["modalities"],
            train_ratio=config["data"].get("train_ratio", 0.8),  # Default if not specified
            val_ratio=config["data"].get("val_ratio", 0.2),  # Default if not specified
            seed=args.seed,  # Use the provided seed for data splitting - different seeds = different splits
        )
        
        # Create datasets
        train_dataset = get_dataset(
            data_dir=config["data"]["data_dir"],
            datalist=datalist_dict["train"],
            mode="train",
            modalities=config["data"]["modalities"],
            cache_rate=config["data"]["cache_rate"],
            num_workers=config["data"]["num_workers"],
            num_samples=config["data"].get("num_samples", 4),  # Get from config or use default 4
        )
        
        val_dataset = get_dataset(
            data_dir=config["data"]["data_dir"],
            datalist=datalist_dict["val"],
            mode="val",
            modalities=config["data"]["modalities"],
            cache_rate=config["data"]["cache_rate"],
            num_workers=config["data"]["num_workers"],
            num_samples=config["data"].get("num_samples", 4),  # Get from config or use default 4
        )
        
        # Create samplers for distributed training
        train_sampler = None
        val_sampler = None
        
        if args.distributed:
            train_sampler = DistributedSampler(train_dataset)
            val_sampler = DistributedSampler(val_dataset, shuffle=False)
        
        # Create dataloaders
        train_dataloader = get_dataloader(
            dataset=train_dataset,
            batch_size=config["training"]["batch_size"],
            shuffle=(train_sampler is None),  # Only shuffle if not using sampler
            num_workers=config["data"]["num_workers"],
            sampler=train_sampler,
            pin_memory=True,
        )
        
        val_dataloader = get_dataloader(
            dataset=val_dataset,
            batch_size=config["training"]["batch_size"],
            shuffle=False,
            num_workers=config["data"]["num_workers"],
            sampler=val_sampler,
            pin_memory=True,
        )
        
        dataloaders = {
            "train": train_dataloader,
            "val": val_dataloader,
        }
        
        if args.distributed:
            dataloaders["train_sampler"] = train_sampler
            dataloaders["val_sampler"] = val_sampler
    
    # Create model
    model = create_model(
        model_name=config["model"]["name"],
        in_channels=config["model"]["in_channels"],
        out_channels=config["model"]["out_channels"],
        img_size=config["model"]["img_size"],
        feature_size=config["model"]["feature_size"],
        use_checkpoint=config["model"]["use_checkpoint"],
        spatial_dims=config["model"].get("spatial_dims", 3),
        depths=config["model"].get("depths", (2, 2, 2, 2)),
        num_heads=config["model"].get("num_heads", (3, 6, 12, 24)),
        norm_name=config["model"].get("norm_name", "instance"),
        drop_rate=config["model"].get("drop_rate", 0.0),
        attn_drop_rate=config["model"].get("attn_drop_rate", 0.0),
        dropout_path_rate=config["model"].get("dropout_path_rate", 0.0),
        normalize=config["model"].get("normalize", True),
        encoding=config["model"].get("encoding", "rand_embedding"),
        mode= args.mode,
    )
    
    # Move model to device
    model = model.to(args.device)
    
    #Load the checkpoint
    if args.checkpoint:
        if args.phase == "multimodal_adaptation":
            if not args.distributed or args.rank == 0:
                print("Loading checkpoint for multimodal adaptation phase...")
            # Load the checkpoint
            checkpoint = torch.load(args.checkpoint, weights_only=False)
            
            # Handle PEFT-style checkpoints by removing prefixes
            if "model_state_dict" in checkpoint:
                state_dict = checkpoint["model_state_dict"]
                # Regular checkpoint
                model.load_state_dict(state_dict, strict=False)
                if not args.distributed or args.rank == 0:
                    print("Loaded regular checkpoint without key remapping")
                
                # Only copy patch_embed weights in multimodal_adaptation phase
                if not args.distributed or args.rank == 0:
                    print("Copying pretrained CT patch_embed weights to PET patch_embed...")
                model.swinViT.patch_embed_pet.load_state_dict(model.swinViT.patch_embed.state_dict())

            # Create PEFT config first
            if not args.distributed or args.rank == 0:
                print(f"Using PEFT method: {args.peft_method}")

            peft_config = LoraConfig(
                use_dora=(args.peft_method == "dora"),  # Enable DoRA if selected
                # task_type=TaskType.FEATURE_EXTRACTION,
                inference_mode=False,
                r=args.lora_r,
                lora_alpha=args.lora_alpha,
                lora_dropout=args.lora_dropout,
                target_modules=args.target_modules.split(','),
                # Add modules_to_save parameter to exclude patch embedding layers from LoRA adaptation
                modules_to_save=[
                    # Patch embedding modules (both CT and PET pathways)
                    "patch_embed_pet",
                    # Adapters and projections
                    "encoder1_pet", 
                    "ctpet_proj", "ct_adapter", "pet_adapter",
                ],
            )
            
            # Wrap the model with our wrapper
            model = VisionModelWrapper(model, peft_config)

            
            # Now freeze/unfreeze parameters AFTER creating the PEFT model
            # This ensures we correctly handle the LoRA parameters
            unfreeze_modules = args.unfreeze_modules.split(',')
            frozen_count = 0
            unfrozen_count = 0
            
            for name, param in model.named_parameters():
                should_unfreeze = any(module_name in name for module_name in unfreeze_modules)
                # Also keep LoRA parameters unfrozen
                should_unfreeze = should_unfreeze or 'lora' in name.lower()
                
                if not should_unfreeze:
                    param.requires_grad = False
                    frozen_count += param.numel()
                else:
                    param.requires_grad = True
                    unfrozen_count += param.numel()
                    if not args.distributed or args.rank == 0:
                        print(f"Keeping unfrozen: {name}")
            
            if not args.distributed or args.rank == 0:
                print(f"Frozen parameters: {frozen_count}")
                print(f"Unfrozen parameters: {unfrozen_count}")
                print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad)}")
                print(f"Total parameters: {sum(p.numel() for p in model.parameters())}")

        elif args.phase.startswith("continual_learning"):
            if not args.distributed or args.rank == 0:
                print("Loading checkpoint for continual learning phase...")
            
            # Load the checkpoint for state_dict loading
            checkpoint = torch.load(args.checkpoint, weights_only=False)
            
            # First load adapter weights from the peft_checkpoint
            peft_model = PeftModel.from_pretrained(
                model, 
                args.peft_checkpoint,  # Use peft_checkpoint for the adapter weights
                is_trainable=True,     # Ensure all adapter weights are trainable
                inference_mode=False   # Important to set for training
            )

            # Wrap the model with our wrapper
            model = VisionModelWrapper(peft_model)
            
            # Now load the full model weights including the base model
            if "model_state_dict" in checkpoint:
                state_dict = checkpoint["model_state_dict"]
                model.load_state_dict(state_dict, strict=True)
            
            # Determine training mode and specific adapter to train
            train_mode = args.train_mode if args.train_mode is not None else args.mode
            training_single_modality = train_mode in ["ct", "pet"]
            adapter_to_train = f"{train_mode}_adapter" if training_single_modality else None
            
            if not args.distributed or args.rank == 0:
                if training_single_modality:
                    print(f"\n===== SELECTIVE ADAPTER TRAINING =====")
                    print(f"Training mode: {train_mode}")
                    print(f"Only training the {adapter_to_train} adapter")
                    print(f"All other parameters including LoRA will be frozen")
                else:
                    print(f"\n===== STANDARD CONTINUAL LEARNING =====")
                    print(f"Training mode: {train_mode}")
                    print(f"Training LoRA parameters and specified modules: {args.unfreeze_modules}")
            
            # Now freeze/unfreeze parameters AFTER loading both adapter and full weights
            # This ensures we correctly handle all parameters
            unfreeze_modules = args.unfreeze_modules.split(',')
            frozen_count = 0
            unfrozen_count = 0
            lora_count = 0
            
            for name, param in model.named_parameters():
                # For single modality training with specific adapter, only unfreeze that adapter
                if training_single_modality:
                    should_unfreeze = adapter_to_train in name
                    # is_lora_param = False  # Don't consider LoRA status in this case
                    is_lora_param = 'lora' in name.lower()
                else:
                    # Standard continual learning mode: unfreeze LoRA and specified modules
                    is_lora_param = 'lora' in name.lower()
                    should_unfreeze = any(module_name in name for module_name in unfreeze_modules)

                # Either adapter-only or standard unfreezing logic
                if is_lora_param or should_unfreeze:
                    param.requires_grad = True
                    unfrozen_count += param.numel()
                    
                    if is_lora_param:
                        lora_count += param.numel()
                        
                    if not args.distributed or args.rank == 0:
                        reason = "adapter parameter" if adapter_to_train and adapter_to_train in name else "LoRA parameter" if is_lora_param else "specified module"
                        print(f"Keeping unfrozen: {name} ({reason})")
                else:
                    param.requires_grad = False
                    frozen_count += param.numel()
            


            if not args.distributed or args.rank == 0:
                print(f"\n===== PARAMETER ANALYSIS =====")
                print(f"Frozen parameters: {frozen_count:,}")
                print(f"Unfrozen parameters: {unfrozen_count:,}")
                
                if not training_single_modality:
                    print(f"LoRA parameters (subset of unfrozen): {lora_count:,}")
                    
                print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
                print(f"Total parameters: {sum(p.numel() for p in model.parameters()):,}")
                print(f"Percentage trainable: {(unfrozen_count/sum(p.numel() for p in model.parameters()))*100:.3f}%")
                
                if training_single_modality:
                    print(f"\nNOTE: Only the {adapter_to_train} is trainable. This ensures")
                    print(f"we don't forget the knowledge in other pathways when training")
                    print(f"with only {train_mode.upper()} data.")
                else:
                    print("\nNOTE: Both LoRA parameters and specified modules are trainable.")
                    print("This is the standard continual learning setup.")

    else:
        print("No checkpoint provided, training from scratch")

    # The following sections are redundant now that we've implemented phase-specific parameter handling
    # Remove general parameter freezing code
    
    # Wrap model with DDP for distributed training
    if args.distributed:
        if args.peft_method in ["lora", "dora"]:
            # For LoRA/DoRA with wrapper, we need to wrap the entire model
            model = DDP(model, device_ids=[args.gpu], find_unused_parameters=True)
        else:
            # For direct method, wrap as usual
            model = DDP(model, device_ids=[args.gpu], find_unused_parameters=True)
            
        # Set static graph for models with checkpointing to avoid DDP errors
        if config["model"]["use_checkpoint"]:
            model._set_static_graph()
    
    # Print model summary (only for rank 0)
    if not args.distributed or args.rank == 0:
        print(f"Model: {config['model']['name']}")
        print(f"Parameters: {sum(p.numel() for p in model.parameters())}")
        print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad)}")
    
    # Add wandb config to training config
    if (args.use_wandb or ("logging" in config and config["logging"].get("use_wandb", False))) and (not args.distributed or args.rank == 0):
        config["training"]["use_wandb"] = True
        config["training"]["wandb_project"] = args.wandb_project if args.wandb_project != "pemma" else config["logging"].get("wandb_project", "pemma")
        config["training"]["wandb_entity"] = args.wandb_entity if args.wandb_entity is not None else config["logging"].get("wandb_entity", None)
    else:
        config["training"]["use_wandb"] = False
    
    # Update training config for distributed training
    config["training"]["distributed"] = args.distributed
    config["training"]["rank"] = args.rank
    config["training"]["world_size"] = args.world_size
    config["training"]["device"] = args.device
    
    # Add training strategy configuration
    config["training"]["training_strategy"] = args.training_strategy
    config["training"]["train_mode"] = args.train_mode if args.train_mode is not None else args.mode
    
    # Parse comma-separated lists
    if args.modes:
        config["training"]["modes"] = args.modes.split(',')
    
    if args.mode_weights:
        config["training"]["mode_weights"] = [float(w) for w in args.mode_weights.split(',')]
        
    config["training"]["val_mode"] = args.val_mode
    
    # Create trainer using the factory function
    trainer = get_trainer(
        model=model,
        train_loader=dataloaders["train"],
        val_loader=dataloaders["val"],
        config=config["training"],
    )
    
    # Set output directory and checkpoint path
    trainer.save_dir = output_dir
    trainer.checkpoint_path = args.checkpoint
    
    # Set distributed samplers if available
    if args.distributed:
        trainer.train_sampler = dataloaders.get("train_sampler")
        trainer.val_sampler = dataloaders.get("val_sampler")
    
    # Train model
    trainer.train()
    
    # Save final model (only for rank 0)
    if not args.distributed or args.rank == 0:
        print("Training completed. Saving final checkpoint...")
        trainer.save_checkpoint(is_best=False)
    
    # Close tensorboard writer
    if writer is not None:
        writer.close()
    
    # Clean up distributed training
    if args.distributed:
        dist.destroy_process_group()


def main():
    args = parse_args()
    
    if args.distributed:
        # Use all available GPUs
        if args.gpu is None:
            args.world_size = torch.cuda.device_count()
            mp.spawn(main_worker, nprocs=args.world_size, args=(args,))
        else:
            # Use specific GPU
            main_worker(args.gpu, args)
    else:
        # Single GPU or CPU training
        if args.gpu is not None:
            torch.cuda.set_device(args.gpu)
            args.device = torch.device(f"cuda:{args.gpu}")
        else:
            args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        main_worker(args.gpu, args)


if __name__ == "__main__":
    main() 

