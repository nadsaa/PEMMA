#!/usr/bin/env python
"""
Training script for SwinUNETR model.
"""

import os
import sys
import argparse
import yaml
import json
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
import numpy as np
import random
from torch.utils.tensorboard import SummaryWriter

# Add the project root to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.dataset import load_strategy_config, get_phase_dataloaders
from src.models.model import create_model
from src.trainers.trainer import Trainer, get_trainer


def set_seed(seed: int = 42) -> None:
    """
    Set random seed for reproducibility.
    
    Args:
        seed: Random seed
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def parse_args():
    parser = argparse.ArgumentParser(description="Train SwinUNETR model")
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to the configuration file",
    )
    parser.add_argument(
        "--strategy",
        type=str,
        required=False,
        help="Path to the training strategy configuration file (for HECKTOR dataset)",
    )
    parser.add_argument(
        "--phase",
        type=str,
        required=True,
        choices=["pretraining"],
        help="Phase of the training strategy to use (for HECKTOR dataset)",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to the checkpoint file for resuming training",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./outputs",
        help="Path to the output directory",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )
    parser.add_argument(
        "--use-wandb",
        action="store_true",
        help="Whether to use Weights & Biases for logging",
    )
    parser.add_argument(
        "--wandb-project",
        type=str,
        default="pemma",
        help="Weights & Biases project name",
    )
    parser.add_argument(
        "--wandb-entity",
        type=str,
        default=None,
        help="Weights & Biases entity name",
    )
    parser.add_argument(
        "--distributed",
        action="store_true",
        help="Whether to use distributed training",
    )
    parser.add_argument(
        "--world-size",
        type=int,
        default=4,
        help="Number of processes for distributed training",
    )
    parser.add_argument(
        "--dist-url",
        default="tcp://localhost:23456",
        help="URL used to set up distributed training",
    )
    parser.add_argument(
        "--dist-backend",
        default="nccl",
        help="Distributed backend",
    )
    parser.add_argument(
        "--gpu",
        default=None,
        type=int,
        help="GPU id to use. If None, will use all available GPUs with --distributed",
    )
    parser.add_argument(
        "--rank",
        default=0,
        type=int,
        help="Node rank for distributed training",
    )
    return parser.parse_args()


def setup_distributed(args):
    """
    Setup distributed training.
    
    Args:
        args: Command line arguments
    """
    if args.gpu is not None:
        # Single GPU training
        torch.cuda.set_device(args.gpu)
        args.device = torch.device(f"cuda:{args.gpu}")
        args.rank = 0
        args.world_size = 1
    else:
        # Multi-GPU training
        args.device = torch.device("cuda")
        if args.distributed:
            if args.dist_url == "env://" and args.rank == -1:
                args.rank = int(os.environ["RANK"])
            
            dist.init_process_group(
                backend=args.dist_backend,
                init_method=args.dist_url,
                world_size=args.world_size,
                rank=args.rank,
            )
            # Set the device to the local rank
            args.gpu = args.rank % torch.cuda.device_count()
            torch.cuda.set_device(args.gpu)
            args.device = torch.device(f"cuda:{args.gpu}")
            
            print(f"Initialized process group: rank {args.rank}, world_size {args.world_size}, device {args.device}")


def main_worker(gpu, args):
    """
    Main worker function for distributed training.
    
    Args:
        gpu: GPU ID
        args: Command line arguments
    """
    args.gpu = gpu
    
    # Setup distributed training if needed
    if args.distributed:
        args.rank = args.rank * torch.cuda.device_count() + gpu
        dist.init_process_group(
            backend=args.dist_backend,
            init_method=args.dist_url,
            world_size=args.world_size,
            rank=args.rank,
        )
        torch.cuda.set_device(args.gpu)
        args.device = torch.device(f"cuda:{args.gpu}")  # Set the device attribute
    else:
        # For non-distributed training, also set the device
        args.device = torch.device(f"cuda:{args.gpu}" if args.gpu is not None else "cuda")
    
    # Set random seed
    set_seed(args.seed + args.rank)  # Different seed for each process
    
    # Load configuration
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Create tensorboard writer (only for rank 0)
    writer = None
    if not args.distributed or args.rank == 0:
        writer = SummaryWriter(log_dir=str(output_dir / "logs"))
    
    # Determine if we're using the HECKTOR dataset with strategy
    using_hecktor_strategy = args.strategy is not None and args.phase is not None
    
    # Get dataloaders
    if using_hecktor_strategy:
        if not args.distributed or args.rank == 0:
            print(f"Using HECKTOR dataset with strategy phase: {args.phase}")
        
        # Load strategy configuration
        strategy_config = load_strategy_config(args.strategy)
        phase_config = strategy_config["phases"][args.phase]
        
        # Update config with phase-specific settings
        config["data"]["modalities"] = phase_config["modalities"]
        
        # Adjust model input channels based on number of modalities
        config["model"]["in_channels"] = len(phase_config["modalities"])
        
        # Get dataloaders for the specified phase
        dataloaders = get_phase_dataloaders(
            data_dir=config["data"]["data_dir"],
            config_path=args.strategy,
            phase=args.phase,
            batch_size=config["training"]["batch_size"],
            num_workers=config["data"]["num_workers"],
            cache_rate=config["data"]["cache_rate"],
            seed=args.seed,
            num_samples=config["data"].get("num_samples", 4),  # Get from config or use default 4
        )
        
        # Add distributed samplers if using distributed training
        if args.distributed:
            train_sampler = DistributedSampler(dataloaders["train"].dataset)
            val_sampler = DistributedSampler(dataloaders["val"].dataset, shuffle=False)
            
            # Recreate dataloaders with distributed samplers
            from src.data.dataset import get_dataloader
            
            train_dataloader = get_dataloader(
                dataset=dataloaders["train"].dataset,
                batch_size=config["training"]["batch_size"],
                shuffle=False,  # Sampler handles shuffling
                num_workers=config["data"]["num_workers"],
                sampler=train_sampler,
                pin_memory=True,
            )
            
            val_dataloader = get_dataloader(
                dataset=dataloaders["val"].dataset,
                batch_size=config["training"]["batch_size"],
                shuffle=False,
                num_workers=config["data"]["num_workers"],
                sampler=val_sampler,
                pin_memory=True,
            )
            
            dataloaders = {
                "train": train_dataloader,
                "val": val_dataloader,
                "train_sampler": train_sampler,
                "val_sampler": val_sampler,
            }
    else:
        # Use the standard dataset preparation
        from src.data.dataset import prepare_datalist, get_dataset, get_dataloader
        
        # Prepare datalist with fixed seed for data splitting (reproducible splits across different model seeds)
        datalist_dict = prepare_datalist(
            data_dir=config["data"]["data_dir"],
            centers=config["data"].get("centers", []),
            modalities=config["data"]["modalities"],
            train_ratio=config["data"].get("train_ratio", 0.8),  # Default if not specified
            val_ratio=config["data"].get("val_ratio", 0.2),  # Default if not specified
            seed=args.seed,  # Use the provided seed for data splitting - different seeds = different splits
        )
        
        # Create datasets
        train_dataset = get_dataset(
            data_dir=config["data"]["data_dir"],
            datalist=datalist_dict["train"],
            mode="train",
            modalities=config["data"]["modalities"],
            cache_rate=config["data"]["cache_rate"],
            num_workers=config["data"]["num_workers"],
            num_samples=config["data"].get("num_samples", 4),  # Get from config or use default 4
        )
        
        val_dataset = get_dataset(
            data_dir=config["data"]["data_dir"],
            datalist=datalist_dict["val"],
            mode="val",
            modalities=config["data"]["modalities"],
            cache_rate=config["data"]["cache_rate"],
            num_workers=config["data"]["num_workers"],
            num_samples=config["data"].get("num_samples", 4),  # Get from config or use default 4
        )
        
        # Create samplers for distributed training
        train_sampler = None
        val_sampler = None
        
        if args.distributed:
            train_sampler = DistributedSampler(train_dataset)
            val_sampler = DistributedSampler(val_dataset, shuffle=False)
        
        # Create dataloaders
        train_dataloader = get_dataloader(
            dataset=train_dataset,
            batch_size=config["training"]["batch_size"],
            shuffle=(train_sampler is None),  # Only shuffle if not using sampler
            num_workers=config["data"]["num_workers"],
            sampler=train_sampler,
            pin_memory=True,
        )
        
        val_dataloader = get_dataloader(
            dataset=val_dataset,
            batch_size=config["training"]["batch_size"],
            shuffle=False,
            num_workers=config["data"]["num_workers"],
            sampler=val_sampler,
            pin_memory=True,
        )
        
        dataloaders = {
            "train": train_dataloader,
            "val": val_dataloader,
        }
        
        if args.distributed:
            dataloaders["train_sampler"] = train_sampler
            dataloaders["val_sampler"] = val_sampler
    
    # Create model
    model = create_model(
        model_name=config["model"]["name"],
        in_channels=config["model"]["in_channels"],
        out_channels=config["model"]["out_channels"],
        img_size=config["model"]["img_size"],
        feature_size=config["model"]["feature_size"],
        use_checkpoint=config["model"]["use_checkpoint"],
        spatial_dims=config["model"].get("spatial_dims", 3),
        depths=config["model"].get("depths", (2, 2, 2, 2)),
        num_heads=config["model"].get("num_heads", (3, 6, 12, 24)),
        norm_name=config["model"].get("norm_name", "instance"),
        drop_rate=config["model"].get("drop_rate", 0.0),
        attn_drop_rate=config["model"].get("attn_drop_rate", 0.0),
        dropout_path_rate=config["model"].get("dropout_path_rate", 0.0),
        normalize=config["model"].get("normalize", True),
        encoding=config["model"].get("encoding", "rand_embedding"),
        mode= None,
    )
    
    # Move model to device
    model = model.to(args.device)
    
    # breakpoint()
    
    if args.checkpoint is not None:
        print(f"Loading checkpoint from {args.checkpoint}")
        ckpt = torch.load(args.checkpoint)
        ckpt["net"] = {k.replace('module.backbone.', ''): v for k, v in ckpt["net"].items()}
        model.load_state_dict(ckpt["net"], strict=False)
        # Missing key(s) in state_dict: "out.conv.conv.weight", "out.conv.conv.bias". 
        # Unexpected key(s) in state_dict: "module.organ_embedding", "module.precls_conv.0.weight", "module.precls_conv.0.bias", "module.precls_conv.2.weight", "module.precls_conv.2.bias", "module.GAP.0.weight", "module.GAP.0.bias", "module.GAP.3.weight", "module.GAP.3.bias", "module.controller.weight", "module.controller.bias", "module.text_to_vision.weight", "module.text_to_vision.bias".
    
    # Wrap model with DDP for distributed training
    if args.distributed:
        model = DDP(model, device_ids=[args.gpu], find_unused_parameters=True)
        # Set static graph for models with checkpointing to avoid DDP errors
        if config["model"]["use_checkpoint"]:
            model._set_static_graph()
    
    # Print model summary (only for rank 0)
    if not args.distributed or args.rank == 0:
        print(f"Model: {config['model']['name']}")
        print(f"Parameters: {sum(p.numel() for p in model.parameters())}")
        print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad)}")
    
    # Add wandb config to training config
    if (args.use_wandb or ("logging" in config and config["logging"].get("use_wandb", False))) and (not args.distributed or args.rank == 0):
        config["training"]["use_wandb"] = True
        config["training"]["wandb_project"] = args.wandb_project if args.wandb_project != "pemma" else config["logging"].get("wandb_project", "pemma")
        config["training"]["wandb_entity"] = args.wandb_entity if args.wandb_entity is not None else config["logging"].get("wandb_entity", None)
    else:
        config["training"]["use_wandb"] = False
    
    # Update training config for distributed training
    config["training"]["distributed"] = args.distributed
    config["training"]["rank"] = args.rank
    config["training"]["world_size"] = args.world_size
    config["training"]["device"] = args.device
    
    # Create trainer using the factory function
    trainer = get_trainer(
        model=model,
        train_loader=dataloaders["train"],
        val_loader=dataloaders["val"],
        config=config["training"],
    )
        
    # Set output directory and checkpoint path
    trainer.save_dir = output_dir
    trainer.checkpoint_path = args.checkpoint
    
    # Set distributed samplers if available
    if args.distributed:
        trainer.train_sampler = dataloaders.get("train_sampler")
        trainer.val_sampler = dataloaders.get("val_sampler")
    
    # Train model
    trainer.train()
    
    # Save final model (only for rank 0)
    if not args.distributed or args.rank == 0:
        trainer.save_checkpoint(is_best=False)
    
    # Close tensorboard writer
    if writer is not None:
        writer.close()
    
    # Clean up distributed training
    if args.distributed:
        dist.destroy_process_group()


def main():
    args = parse_args()
    
    if args.distributed:
        # Use all available GPUs
        if args.gpu is None:
            args.world_size = torch.cuda.device_count()
            mp.spawn(main_worker, nprocs=args.world_size, args=(args,))
        else:
            # Use specific GPU
            main_worker(args.gpu, args)
    else:
        # Single GPU or CPU training
        if args.gpu is not None:
            torch.cuda.set_device(args.gpu)
            args.device = torch.device(f"cuda:{args.gpu}")
        else:
            args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        main_worker(args.gpu, args)


if __name__ == "__main__":
    main() 