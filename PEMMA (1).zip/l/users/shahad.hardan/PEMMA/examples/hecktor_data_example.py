#!/usr/bin/env python
"""
Example script demonstrating how to use the dataset module with the HECKTOR training strategy.
"""

import os
import sys
import argparse
import json
from pathlib import Path

import torch
import numpy as np
import matplotlib.pyplot as plt
from monai.visualize import blend_images, matshow3d
from monai.data import list_data_collate

# Add the project root to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.dataset import (
    load_strategy_config,
    get_phase_dataloaders,
    verify_strategy_config,
    get_center_statistics,
    prepare_datalist,
    get_dataset,
    get_dataloader,
    get_transforms
)


def parse_args():
    parser = argparse.ArgumentParser(description="HECKTOR dataset example")
    parser.add_argument(
        "--data-dir",
        type=str,
        default="./dataset/hecktor/",
        help="Path to the HECKTOR dataset directory",
    )
    parser.add_argument(
        "--config-path",
        type=str,
        default="configs/hecktor_strategy.json",
        help="Path to the training strategy configuration file",
    )
    parser.add_argument(
        "--phase",
        type=str,
        default="multimodal_adaptation",
        choices=["pretraining", "multimodal_adaptation", "continual_learning_task1", "continual_learning_task2"],
        help="Phase of the training strategy to demonstrate",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=1,  # Changed to 1 to avoid collation issues
        help="Batch size for the dataloaders",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=0,  # Changed to 0 to avoid multiprocessing issues
        help="Number of workers for data loading",
    )
    parser.add_argument(
        "--cache-rate",
        type=float,
        default=0.0,
        help="Cache rate for CacheDataset",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )
    parser.add_argument(
        "--verify",
        action="store_true",
        help="Verify the training strategy configuration",
    )
    parser.add_argument(
        "--visualize",
        action="store_true",
        help="Visualize a sample from the dataset",
    )
    parser.add_argument(
        "--direct-load",
        action="store_true",
        help="Load data directly without using get_phase_dataloaders",
    )
    return parser.parse_args()


def visualize_sample(sample, slice_idx=None, output_dir="./visualizations", modalities=None):
    """
    Visualize a sample from the dataset.
    
    Args:
        sample: Sample from the dataset
        slice_idx: Index of the slice to visualize (if None, use the middle slice)
        output_dir: Directory to save the visualization
        modalities: List of modalities to label the plots
    """
    # Handle different sample formats
    if isinstance(sample, list):
        sample = sample[0]  # Get the first item if it's a list
    
    # Get the image and label tensors
    image = sample["image"].cpu().numpy()
    label = sample["label"].cpu().numpy()
    
    # Get the number of modalities
    num_modalities = image.shape[0]
    
    # If slice_idx is None, use the middle slice
    if slice_idx is None:
        slice_idx = image.shape[1] // 2
    
    # Create a figure
    fig, axes = plt.subplots(1, num_modalities + 1, figsize=(4 * (num_modalities + 1), 4))
    
    # Handle the case where there's only one modality
    if num_modalities == 1:
        axes = [axes[0], axes[1]]
    
    # Plot each modality
    for i in range(num_modalities):
        axes[i].imshow(image[i, slice_idx], cmap="gray")
        # Use modality name if provided
        if modalities and i < len(modalities):
            axes[i].set_title(f"{modalities[i].upper()}")
        else:
            axes[i].set_title(f"Modality {i}")
        axes[i].axis("off")
    
    # Plot the label
    axes[-1].imshow(label[0, slice_idx], cmap="viridis")
    axes[-1].set_title("Label")
    axes[-1].axis("off")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get patient ID if available
    patient_id = sample.get("patient_id", "unknown")
    
    # Save the figure
    output_path = os.path.join(output_dir, f"{patient_id}_slice_{slice_idx}.png")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    
    print(f"Visualization saved to {output_path}")


def print_dataset_stats(dataloaders, phase, config):
    """
    Print statistics about the dataset.
    
    Args:
        dataloaders: Dictionary with train and val dataloaders
        phase: Phase of the training strategy
        config: Training strategy configuration
    """
    phase_config = config["phases"][phase]
    
    print(f"\n=== Dataset Statistics for {phase} ===")
    print(f"Centers: {', '.join(phase_config['centers'])}")
    print(f"Modalities: {', '.join(phase_config['modalities'])}")
    print(f"Train samples: {len(dataloaders['train'].dataset)}")
    print(f"Val samples: {len(dataloaders['val'].dataset)}")
    
    # Get a sample from the train dataset directly to avoid DataLoader issues
    sample = dataloaders['train'].dataset[0]
    
    print(f"\n=== Sample Information ===")
    
    # Handle different sample formats
    if isinstance(sample, list):
        print("Sample is a list. First item:")
        sample = sample[0]  # Get the first item if it's a list
    
    print(f"Sample keys: {sample.keys()}")
    
    # Check if the sample has been transformed
    if "image" in sample and torch.is_tensor(sample["image"]):
        print(f"Image shape: {sample['image'].shape}")
        print(f"Label shape: {sample['label'].shape}")
        
        # Print unique label values
        unique_labels = torch.unique(sample["label"]).cpu().numpy()
        print(f"Unique label values: {unique_labels}")
        
        # Print image statistics
        image_min = torch.min(sample["image"]).item()
        image_max = torch.max(sample["image"]).item()
        image_mean = torch.mean(sample["image"]).item()
        image_std = torch.std(sample["image"]).item()
        
        print(f"Image min: {image_min:.4f}")
        print(f"Image max: {image_max:.4f}")
        print(f"Image mean: {image_mean:.4f}")
        print(f"Image std: {image_std:.4f}")
    else:
        print("Sample has not been transformed yet. Raw data paths:")
        for key, value in sample.items():
            if key not in ["patient_id", "center"]:
                print(f"  {key}: {value}")


def load_single_sample(data_dir, phase_config):
    """
    Load a single sample directly to test the transforms.
    
    Args:
        data_dir: Data directory
        phase_config: Configuration for the phase
        
    Returns:
        Transformed sample
    """
    # Get a sample file from the first center
    center = phase_config["centers"][0]
    modalities = phase_config["modalities"]
    
    # Find a CT file from this center
    data_dir = Path(data_dir)
    ct_files = list(data_dir.glob(f"{center}*_ct.nii.gz"))
    
    if not ct_files:
        print(f"No CT files found for center {center}")
        return None
    
    # Use the first CT file
    ct_file = ct_files[0]
    patient_id = ct_file.stem.split("_")[0]
    gt_file = data_dir / f"{patient_id}_gt.nii.gz"
    
    if not gt_file.exists():
        print(f"Ground truth file not found: {gt_file}")
        return None
    
    # Create a sample dictionary
    sample = {
        "label": str(gt_file),
        "patient_id": patient_id,
        "center": center,
    }
    
    # Add all required modality files
    for modality in modalities:
        modality_file = data_dir / f"{patient_id}_{modality}.nii.gz"
        if not modality_file.exists():
            print(f"Modality file not found: {modality_file}")
            return None
        sample[modality] = str(modality_file)
    
    # Get transforms
    transforms = get_transforms(mode="train", modalities=modalities)
    
    # Apply transforms
    try:
        transformed = transforms(sample)
        print("Transforms applied successfully!")
        
        # Handle the case where the result is a list
        if isinstance(transformed, list):
            print("Transform returned a list. Using the first item.")
            transformed = transformed[0]
            
        return transformed
    except Exception as e:
        print(f"Error applying transforms: {e}")
        import traceback
        traceback.print_exc()
        return None


def main():
    args = parse_args()
    
    # Load the training strategy configuration
    config = load_strategy_config(args.config_path)
    
    # Print center statistics
    print("=== Center Statistics ===")
    center_stats = get_center_statistics(args.data_dir)
    print(center_stats)
    
    # Verify the training strategy configuration if requested
    if args.verify:
        print("\n=== Verifying Training Strategy Configuration ===")
        verification = verify_strategy_config(args.config_path, args.data_dir)
        
        # Print verification results
        print(f"Overall verification: {'Passed' if verification['overall'] else 'Failed'}")
        
        print("\nCenter Verification:")
        for center, result in verification["centers"].items():
            status = "✓" if result["match"] else "✗"
            print(f"  {center}: {status} (Expected: {result['expected']}, Actual: {result['actual']})")
        
        print("\nPhase Verification:")
        for phase, result in verification["phases"].items():
            train_status = "✓" if result["train"]["match"] else "✗"
            val_status = "✓" if result["val"]["match"] else "✗"
            
            print(f"  {phase}:")
            print(f"    Train: {train_status} (Expected: {result['train']['expected']}, Actual: {result['train']['actual']})")
            print(f"    Val: {val_status} (Expected: {result['val']['expected']}, Actual: {result['val']['actual']})")
    
    # Get phase configuration
    phase_config = config["phases"][args.phase]
    modalities = phase_config["modalities"]
    print(f"\nPhase: {args.phase}")
    print(f"Modalities: {', '.join(modalities)}")
    
    # Try loading a single sample directly
    print("\n=== Testing Direct Sample Loading ===")
    sample = load_single_sample(args.data_dir, phase_config)
    
    if sample:
        print(f"Sample keys: {sample.keys()}")
        print(f"Image shape: {sample['image'].shape}")
        print(f"Label shape: {sample['label'].shape}")
        
        # Visualize the sample if requested
        if args.visualize:
            print("\n=== Visualizing Direct Sample ===")
            visualize_sample(sample, modalities=modalities)
    
    # Get dataloaders for the specified phase
    print(f"\n=== Getting Dataloaders for {args.phase} ===")
    
    try:
        if args.direct_load:
            # Use direct dataset loading to avoid potential issues with get_phase_dataloaders
            
            # Prepare datalist
            datalist_dict = prepare_datalist(
                data_dir=args.data_dir,
                centers=phase_config["centers"],
                modalities=modalities,
                train_ratio=phase_config["train_ratio"],
                val_ratio=phase_config["val_ratio"],
                seed=args.seed,
            )
            
            # Create datasets
            train_dataset = get_dataset(
                data_dir=args.data_dir,
                datalist=datalist_dict["train"],
                mode="train",
                modalities=modalities,
                cache_rate=args.cache_rate,
                num_workers=args.num_workers,
            )
            
            val_dataset = get_dataset(
                data_dir=args.data_dir,
                datalist=datalist_dict["val"],
                mode="val",
                modalities=modalities,
                cache_rate=args.cache_rate,
                num_workers=args.num_workers,
            )
            
            # Create dataloaders with custom collate_fn
            train_dataloader = get_dataloader(
                dataset=train_dataset,
                batch_size=args.batch_size,
                shuffle=True,
                num_workers=args.num_workers,
                pin_memory=False,  # Disable pin_memory to avoid potential issues
            )
            
            val_dataloader = get_dataloader(
                dataset=val_dataset,
                batch_size=args.batch_size,
                shuffle=False,
                num_workers=args.num_workers,
                pin_memory=False,  # Disable pin_memory to avoid potential issues
            )
            
            dataloaders = {
                "train": train_dataloader,
                "val": val_dataloader,
            }
        else:
            # Use the standard get_phase_dataloaders function
            dataloaders = get_phase_dataloaders(
                data_dir=args.data_dir,
                config_path=args.config_path,
                phase=args.phase,
                batch_size=args.batch_size,
                num_workers=args.num_workers,
                cache_rate=args.cache_rate,
                seed=args.seed,
            )
        
        # Print dataset statistics
        print_dataset_stats(dataloaders, args.phase, config)
        
        # Visualize a sample if requested and not already visualized
        if args.visualize and not sample:
            print("\n=== Visualizing Sample from DataLoader ===")
            # Get a sample directly from the dataset to avoid DataLoader issues
            sample = dataloaders["train"].dataset[0]
            if isinstance(sample, list):
                sample = sample[0]
            visualize_sample(sample, modalities=modalities)
    
    except Exception as e:
        print(f"Error with dataloaders: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main() 