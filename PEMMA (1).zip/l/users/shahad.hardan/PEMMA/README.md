# PEMMA: SwinUNETR for 3D Medical Imaging with PEFT

A deep learning project for medical image segmentation using SwinUNETR with Parameter-Efficient Fine-Tuning (PEFT) techniques for CT and PET scans. This project implements three key workflows: CT pretraining, CT+PET multimodal adaptation, and continual learning across different medical centers.

## Project Overview

This project implements a SwinUNETR-based architecture for 3D medical image segmentation with a focus on parameter-efficient adaptation strategies. The workflow includes:

1. **CT Pretraining**: Initial model training on CT scans
2. **Multimodal Adaptation**: Extending the CT-trained model to handle CT+PET scans using LoRA/DoRA
3. **Continual Learning**: Adapting models to new medical centers while preserving previous knowledge

### Key Features

- 3D medical image segmentation using SwinUNETR
- Parameter-Efficient Fine-Tuning with LoRA and DoRA
- Multimodal adaptation from CT to CT+PET
- Continual learning across different medical centers
- Comprehensive evaluation metrics for medical imaging
- Support for HECKTOR dataset

## Installation

```bash
# Clone the repository
git clone https://github.com/BioMedIA-MBZUAI/PEMMA.git
cd PEMMA

# Create and activate a virtual environment (recommended: conda)
conda create -n pemma python=3.8
conda activate pemma

# Install dependencies
pip install -r requirements.txt
```

## Project Structure

```
PEMMA/
│
├── configs/              # Configuration files for experiments
│   ├── train_ct.yaml            # CT pretraining configuration
│   ├── finetune_ctpet.yaml      # CT+PET multimodal adaptation config
│   ├── finetune_ct_suprem.yaml  # Continual learning configuration
│   ├── swin_unetr.yaml          # Model architecture configuration
│   ├── hecktor_strategy.json    # Training strategy for HECKTOR dataset
│   └── hecktor2022_clinical_info_training.csv  # Clinical metadata
│
├── src/                  # Source code
│   ├── models/           # Model architectures
│   │   ├── swin_unetr.py        # Core SwinUNETR implementation
│   │   ├── swin_unetr_lora.py   # SwinUNETR with LoRA adaptation
│   │   └── model.py             # Base model classes
│   ├── trainers/         # Training logic
│   │   └── trainer.py           # Main training implementation
│   ├── data/             # Data loading and preprocessing
│   │   ├── dataset.py           # Dataset classes
│   │   ├── preprocess_hecktor.py # HECKTOR data preprocessing
│   │   └── analyze_hecktor.py   # Data analysis utilities
│   ├── evaluation/       # Evaluation tools
│   │   └── evaluate_hecktor2022.py # HECKTOR evaluation metrics
│   └── utils/            # Utility functions
│
├── scripts/              # Training and evaluation scripts
│   ├── train.py          # CT pretraining script
│   ├── finetune.py       # Multimodal adaptation (CT+PET) script
│   ├── finetune_suprem.py # Continual learning script
│   ├── evaluate.py       # Model evaluation script
│   ├── prepare_data.py   # Data preparation utilities
│   └── extract_peft.py   # PEFT parameter extraction
│
├── examples/             # Usage examples
│   └── hecktor_data_example.py  # HECKTOR dataset usage example
│
├── .gitignore            # Git ignore file
├── LICENSE               # License file
├── README.md             # Project README
├── requirements.txt      # Project dependencies
└── setup.py              # Package installation
```

## Usage

### 1. Data Preparation

First, organize your HECKTOR dataset in the expected directory structure:

```bash
# Create dataset directory
mkdir -p dataset/hecktor

# Prepare and preprocess your HECKTOR data
python scripts/prepare_data.py --data_path dataset/hecktor
```

**Expected directory structure after data preparation:**
```
PEMMA/
├── dataset/
│   └── hecktor/
│       ├── imagesTr/     # Training images
│       ├── labelsTr/     # Training labels  
│       └── splits.json   # Data splits
├── checkpoints/          # Model checkpoints (created during training)
└── ...
```

### 2. CT Pretraining

```bash
python scripts/train.py --config configs/train_ct.yaml
```

### 3. Multimodal Adaptation (CT → CT+PET)

```bash
python scripts/finetune.py --config configs/finetune_ctpet.yaml --checkpoint checkpoints/pretraining/swin_unetr_ct_pretraining_best.pt
```

### 4. Continual Learning (New Centers)

```bash
python scripts/finetune_suprem.py --config configs/finetune_ct_suprem.yaml --checkpoint checkpoints/pretraining/swin_unetr_ct_pretraining_best.pt
```

### 5. Model Evaluation

```bash
python scripts/evaluate.py --checkpoint checkpoints/adaptation/model_best.pt --data_path dataset/hecktor
```

### 6. PEFT Parameter Extraction

```bash
python scripts/extract_peft.py --checkpoint checkpoints/adaptation/model_best.pt --output checkpoints/peft_params.pt
```

## Configuration

The project uses YAML configuration files for different training scenarios:

- `train_ct.yaml`: CT-only pretraining settings
- `finetune_ctpet.yaml`: CT+PET multimodal adaptation with LoRA/DoRA
- `finetune_ct_suprem.yaml`: Continual learning across medical centers
- `swin_unetr.yaml`: Model architecture parameters

## Examples

See `examples/hecktor_data_example.py` for detailed usage examples with the HECKTOR dataset.

## License

[MIT License](LICENSE)

## Citation

If you use this code in your research, please cite:

```bibtex
@article{saeed2024pemma,
  title={Efficient Parameter Adaptation for Multi-Modal Medical Image Segmentation and Prognosis},
  author={Saeed, Numan and Hardan, Shahad and Ridzuan, Muhammad and Saadi, Nada and Nandakumar, Karthik and Yaqub, Mohammad},
  journal={arXiv preprint arXiv:2504.13645},
  year={2024},
  url={https://arxiv.org/abs/2504.13645}
}
```

## Acknowledgements

- [MONAI](https://github.com/Project-MONAI/MONAI) for medical imaging tools
- [Hugging Face PEFT](https://github.com/huggingface/peft) for Parameter-Efficient Fine-Tuning techniques
- [HECKTOR Challenge](https://hecktor25.grand-challenge.org/) for the dataset and evaluation framework 