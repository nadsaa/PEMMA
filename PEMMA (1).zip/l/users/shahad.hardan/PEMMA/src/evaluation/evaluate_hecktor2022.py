from pathlib import Path
import json
import os
import sys
import yaml

# Add the project root to the Python path
project_root = str(Path(__file__).parent.parent.parent.absolute())
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import numpy as np
import pandas as pd
import SimpleITK as sitk
import torch
import torch.nn as nn
from monai.inferers import sliding_window_inference
from monai.transforms import AsDiscrete
from monai.metrics import DiceMetric  # Added MONAI Dice metric

from src.models.model import create_model
from src.data.dataset import get_phase_dataloaders, load_strategy_config


def load_config(config_path):
    """Load configuration from YAML file."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def setup_model(config, device='cuda'):
    """Setup model based on configuration."""
    model_config = config['model']
    
    model = create_model(
        model_name=model_config['name'],
        in_channels=model_config['in_channels'],
        out_channels=model_config['out_channels'],
        img_size=model_config['img_size'],
        feature_size=model_config['feature_size'],
        use_checkpoint=model_config.get('use_checkpoint', False),
        spatial_dims=model_config.get('spatial_dims', 3),
        depths=model_config.get('depths', (2, 2, 2, 2)),
        num_heads=model_config.get('num_heads', (3, 6, 12, 24)),
        drop_rate=model_config.get('drop_rate', 0.0),
    )
    
    return model.to(device)


def infer_volume(model, data, roi_size, sw_batch_size=1, device='cuda'):
    """Run inference on a volume using sliding window."""
    model.eval()
    with torch.no_grad():
        image = data['image'].to(device)
        
        # Get the original image shape for reference
        original_shape = image.shape[2:]
        print(f"Original image shape: {original_shape}")
        
        # Run inference with sliding window
        logits = sliding_window_inference(
            inputs=image,
            roi_size=roi_size,
            sw_batch_size=sw_batch_size,
            predictor=model,
            overlap=0.5,
            mode="gaussian",  # Use gaussian mode for better blending
            padding_mode="replicate",  # Replicate padding for better edge handling
        )
        
        print(f"Logits shape after inference: {logits.shape}")
        
        # Apply softmax to get probabilities
        probs = torch.softmax(logits, dim=1)
        print(f"Probabilities shape: {probs.shape}")
        
        # Use argmax for prediction
        preds = torch.argmax(probs, dim=1, keepdim=False).detach().cpu()
        print(f"Predictions shape: {preds.shape}")
        
        return preds


def save_prediction(pred, meta_dict, output_path):
    """Save prediction as NIfTI file."""
    pred_np = pred.numpy().astype(np.uint8)
    pred_sitk = sitk.GetImageFromArray(pred_np)
    pred_sitk.SetSpacing(meta_dict['spacing'])
    pred_sitk.SetOrigin(meta_dict['origin'])
    pred_sitk.SetDirection(meta_dict['direction'])
    sitk.WriteImage(pred_sitk, output_path)
    return pred_sitk


def compute_volumes(im):
    """Compute the volumes of the GTVp and the GTVn."""
    spacing = im.GetSpacing()
    voxvol = spacing[0] * spacing[1] * spacing[2]
    stats = sitk.LabelStatisticsImageFilter()
    stats.Execute(im, im)
    nvoxels1 = stats.GetCount(1)
    nvoxels2 = stats.GetCount(2)
    return nvoxels1 * voxvol, nvoxels2 * voxvol


def compute_agg_dice(intermediate_results):
    """Compute the aggregate dice score from the intermediate results."""
    aggregate_results = {}
    TP1s = [v["TP1"] for v in intermediate_results]
    TP2s = [v["TP2"] for v in intermediate_results]
    vol_sum1s = [v["vol_sum1"] for v in intermediate_results]
    vol_sum2s = [v["vol_sum2"] for v in intermediate_results]
    DSCagg1 = 2 * np.sum(TP1s) / np.sum(vol_sum1s)
    DSCagg2 = 2 * np.sum(TP2s) / np.sum(vol_sum2s)
    aggregate_results['AggregatedDsc'] = {
        'GTVp': DSCagg1,
        'GTVn': DSCagg2,
        'mean': np.mean((DSCagg1, DSCagg2)),
    }
    return aggregate_results


def get_intermediate_metrics(groundtruth, prediction):
    """Compute intermediate metrics for aggregate dice."""
    overlap_measures = sitk.LabelOverlapMeasuresImageFilter()
    overlap_measures.SetNumberOfThreads(1)
    overlap_measures.Execute(groundtruth, prediction)

    DSC1 = overlap_measures.GetDiceCoefficient(1)
    DSC2 = overlap_measures.GetDiceCoefficient(2)

    vol_gt1, vol_gt2 = compute_volumes(groundtruth)
    vol_pred1, vol_pred2 = compute_volumes(prediction)

    vol_sum1 = vol_gt1 + vol_pred1
    vol_sum2 = vol_gt2 + vol_pred2
    TP1 = DSC1 * (vol_sum1) / 2
    TP2 = DSC2 * (vol_sum2) / 2
    return {
        "TP1": TP1,
        "TP2": TP2,
        "vol_sum1": vol_sum1,
        "vol_sum2": vol_sum2,
    }


def compute_monai_dice(groundtruth, prediction):
    """Compute Dice score using MONAI's DiceMetric."""
    # Convert SimpleITK images to numpy arrays
    gt_np = sitk.GetArrayFromImage(groundtruth)
    pred_np = sitk.GetArrayFromImage(prediction)
    
    # Convert to torch tensors with batch dimension [B, C, H, W, D]
    gt_tensor = torch.from_numpy(gt_np).long().unsqueeze(0).unsqueeze(0)
    pred_tensor = torch.from_numpy(pred_np).long().unsqueeze(0).unsqueeze(0)
    
    # Convert to one-hot format for multi-class Dice computation
    num_classes = 3  # Background (0), GTVp (1), GTVn (2)
    gt_one_hot = torch.zeros((1, num_classes, *gt_np.shape))
    pred_one_hot = torch.zeros((1, num_classes, *pred_np.shape))
    
    for c in range(num_classes):
        gt_one_hot[:, c][gt_tensor[:, 0] == c] = 1
        pred_one_hot[:, c][pred_tensor[:, 0] == c] = 1
    
    # Initialize MONAI Dice metric
    dice_metric = DiceMetric(include_background=False, reduction="mean_batch")
    
    # Compute Dice score
    dice_metric(y_pred=pred_one_hot, y=gt_one_hot)
    dice_scores = dice_metric.aggregate().numpy()
    
    # Reset metric for next iteration
    dice_metric.reset()
    
    return {
        'GTVp': float(dice_scores[0]),
        'GTVn': float(dice_scores[1]),
        'mean': float(np.mean(dice_scores))
    }


def main():
    # Define paths
    data_folder = './dataset/hecktor'
    config_path = './configs/train_ct.yaml'
    strategy_path = './configs/hecktor_strategy.json'
    weights_path = './checkpoints/pretraining/swin_unetr_ct_pretraining_best.pt'
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    config = load_config(config_path)
    phase = 'pretraining'
    seed = config.get('seed', 786)
    
    model = setup_model(config, device)
    
    print(f"Loading model weights from {weights_path}")
    checkpoint = torch.load(weights_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    print(f"Creating validation dataloader for phase: {phase}")
    dataloaders = get_phase_dataloaders(
        data_dir=data_folder,
        config_path=strategy_path,
        phase=phase,
        batch_size=1,
        num_workers=4,
        cache_rate=0.0,
        seed=seed,
    )
    val_dataloader = dataloaders['val']
    
    results = []
    monai_results = []
    
    for batch_idx, batch_data in enumerate(val_dataloader):
        print(f"Processing batch {batch_idx+1}/{len(val_dataloader)}")
        
        patient_id = batch_data['patient_id'][0] if isinstance(batch_data['patient_id'], list) else batch_data['patient_id']
        print(f"Patient ID: {patient_id}")
        
        if not hasattr(batch_data['label'], 'meta'):
            print("Label does not have metadata")
        
        pred = infer_volume(
            model=model,
            data=batch_data,
            roi_size=config['model']['img_size'],
            device=device
        )
        
        pred_np = pred[0].numpy().astype(np.uint8)
        print(f"Prediction shape: {pred_np.shape}")
        
        gt_file = [f for f in Path(data_folder).rglob(f'{patient_id}*_gt.nii.gz')][0]
        groundtruth = sitk.ReadImage(str(gt_file.resolve()))
        gt_size = groundtruth.GetSize()
        print(f"Ground truth size: {gt_size}")
        
        pred_sitk = sitk.GetImageFromArray(pred_np)
        pred_size = pred_sitk.GetSize()
        print(f"Prediction size: {pred_size}")
        
        if pred_size != gt_size:
            print(f"Dimensions don't match. Transposing prediction array.")
            pred_np = np.transpose(pred_np, (2, 1, 0))
            pred_sitk = sitk.GetImageFromArray(pred_np)
            print(f"New prediction size: {pred_sitk.GetSize()}")
        
        pred_sitk.SetSpacing(groundtruth.GetSpacing())
        pred_sitk.SetOrigin(groundtruth.GetOrigin())
        pred_sitk.SetDirection(groundtruth.GetDirection())
        print(f"Using ground truth file metadata for patient {patient_id}")
        
        # Compute existing metrics
        metrics = get_intermediate_metrics(groundtruth, pred_sitk)
        results.append(metrics)
        
        # Compute MONAI Dice metrics
        monai_dice = compute_monai_dice(groundtruth, pred_sitk)
        monai_results.append(monai_dice)
        
        print(f"\nMetrics for {patient_id}:")
        print(f"Intermediate metrics (for aggregate Dice):")
        print(f"  TP1: {metrics['TP1']}")
        print(f"  TP2: {metrics['TP2']}")
        print(f"  vol_sum1: {metrics['vol_sum1']}")
        print(f"  vol_sum2: {metrics['vol_sum2']}")
        print(f"MONAI Dice metrics:")
        print(f"  GTVp: {monai_dice['GTVp']:.4f}")
        print(f"  GTVn: {monai_dice['GTVn']:.4f}")
        print(f"  Mean: {monai_dice['mean']:.4f}")
    
    # Compute aggregate dice
    agg_results = compute_agg_dice(results)
    
    # Compute mean MONAI Dice across all patients
    monai_mean_dice = {
        'GTVp': np.mean([r['GTVp'] for r in monai_results]),
        'GTVn': np.mean([r['GTVn'] for r in monai_results]),
        'mean': np.mean([r['mean'] for r in monai_results])
    }
    
    print("\nFinal Results:")
    print("Aggregate Dice (Original Method):")
    print(f"  GTVp: {agg_results['AggregatedDsc']['GTVp']:.4f}")
    print(f"  GTVn: {agg_results['AggregatedDsc']['GTVn']:.4f}")
    print(f"  Mean: {agg_results['AggregatedDsc']['mean']:.4f}")
    print("MONAI Dice (Mean across patients):")
    print(f"  GTVp: {monai_mean_dice['GTVp']:.4f}")
    print(f"  GTVn: {monai_mean_dice['GTVn']:.4f}")
    print(f"  Mean: {monai_mean_dice['mean']:.4f}")


if __name__ == "__main__":
    main()