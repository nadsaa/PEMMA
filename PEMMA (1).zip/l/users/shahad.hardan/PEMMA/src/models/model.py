"""
Model factory module for creating SwinUNETR models.
"""

import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple, Union, Sequence

from src.models.swin_unetr import SwinUNETR
from src.models.swin_unetr_lora import SwinUNETR_LORA

def create_model(
    model_name: str,
    in_channels: int,
    out_channels: int,
    img_size: Union[Sequence[int], int] = (96, 96, 96),
    feature_size: int = 48,
    use_checkpoint: bool = False,
    spatial_dims: int = 3,
    depths: Sequence[int] = (2, 2, 2, 2),
    num_heads: Sequence[int] = (3, 6, 12, 24),
    norm_name: str = "instance",
    drop_rate: float = 0.0,
    attn_drop_rate: float = 0.0,
    dropout_path_rate: float = 0.0,
    normalize: bool = True,
    encoding: str = "rand_embedding",
    mode: str = "ct",
) -> nn.Module:
    """
    Factory function to create a model.
    
    Args:
        model_name: Name of the model to create
        in_channels: Number of input channels
        out_channels: Number of output channels
        img_size: Input image size
        feature_size: Feature size
        use_checkpoint: Whether to use checkpointing
        spatial_dims: Number of spatial dimensions
        depths: Depth of each stage
        num_heads: Number of attention heads in each stage
        norm_name: Normalization layer name
        drop_rate: Dropout rate
        attn_drop_rate: Attention dropout rate
        dropout_path_rate: Drop path rate
        normalize: Whether to normalize features
        encoding: Encoding type
        
    Returns:
        Initialized model
    """
    model_name = model_name.lower()
    
    if model_name == "swin_unetr":
            model = SwinUNETR(
                img_size=img_size,
                in_channels=in_channels,
                out_channels=out_channels,
                feature_size=feature_size,
                depths=depths,
                num_heads=num_heads,
                norm_name=norm_name,
                drop_rate=drop_rate,
                attn_drop_rate=attn_drop_rate,
                dropout_path_rate=dropout_path_rate,
                normalize=normalize,
                use_checkpoint=use_checkpoint,
                spatial_dims=spatial_dims,
            )
    elif model_name == "swin_unetr_lora":
        model = SwinUNETR_LORA(
            img_size=img_size,
                in_channels=in_channels,
                out_channels=out_channels,
                feature_size=feature_size,
                depths=depths,
                num_heads=num_heads,
                norm_name=norm_name,
                drop_rate=drop_rate,
                attn_drop_rate=attn_drop_rate,
                dropout_path_rate=dropout_path_rate,
                normalize=normalize,
                use_checkpoint=use_checkpoint,
                spatial_dims=spatial_dims,
                mode=mode,
        )
    else:
        raise ValueError(f"Unsupported model: {model_name}")
    
    return model