"""
Trainer module for training SwinUNETR models.
"""

import os
import time
import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
from torch.amp import GradScaler, autocast
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Callable

import numpy as np
from tqdm import tqdm
import wandb

from monai.losses import DiceLoss, DiceCELoss, DiceFocalLoss
from monai.metrics import DiceMetric
from monai.inferers import sliding_window_inference
from monai.transforms import AsDiscrete
from monai.data import decollate_batch
import SimpleITK as sitk

import torch_optimizer


class Trainer:
    """
    Trainer class for training SwinUNETR models.
    """
    
    def __init__(
        self,
        model: nn.Module,
        train_loader: torch.utils.data.DataLoader,
        val_loader: torch.utils.data.DataLoader,
        optimizer: torch.optim.Optimizer,
        loss_function: nn.Module,
        lr_scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None,
        device: Union[str, torch.device] = "cuda",
        data_folder: str = "./dataset/hecktor",
        amp: bool = True,
        val_interval: int = 1,
        save_interval: int = 10,
        save_dir: Union[str, Path] = "./checkpoints",
        experiment_name: str = "swin_unetr",
        max_epochs: int = 100,
        num_classes: int = 3,  # Updated to 3 classes (background, tumor, lymph node)
        sw_batch_size: int = 4,
        roi_size: Tuple[int, int, int] = (96, 96, 96),
        use_wandb: bool = False,
        wandb_project: str = "media2025",
        wandb_entity: Optional[str] = None,
        wandb_config: Optional[Dict] = None,
        distributed: bool = False,
        rank: int = 0,
        world_size: int = 1,
        checkpoint_path: Optional[Union[str, Path]] = None,
        training_strategy: str = "random",  # 'random' or 'fixed'
        train_mode: str = "ctpet",  # Mode to use with 'fixed' strategy
        modes: List[str] = None,  # Available modes
        mode_weights: List[float] = None,  # Weights for random selection
        val_mode: str = "all",  # Validation mode
    ):
        """
        Initialize the trainer.
        
        Args:
            model: Model to train
            train_loader: Training data loader
            val_loader: Validation data loader
            optimizer: Optimizer
            loss_function: Loss function
            lr_scheduler: Learning rate scheduler
            device: Device to use
            amp: Whether to use automatic mixed precision
            val_interval: Validation interval (in epochs)
            save_interval: Checkpoint saving interval (in epochs)
            save_dir: Directory to save checkpoints
            experiment_name: Name of the experiment
            max_epochs: Maximum number of epochs
            num_classes: Number of classes
            sw_batch_size: Batch size for sliding window inference
            roi_size: ROI size for sliding window inference
            use_wandb: Whether to use Weights & Biases
            wandb_project: Weights & Biases project name
            wandb_entity: Weights & Biases entity name
            wandb_config: Weights & Biases configuration
            distributed: Whether to use distributed training
            rank: Rank of the current process
            world_size: Number of processes
            checkpoint_path: Path to checkpoint to load
            training_strategy: Strategy for training ('random' or 'fixed')
                - 'fixed': Always use the same mode specified by train_mode
                - 'random': Randomly select a mode for each batch based on modes and mode_weights
            train_mode: Mode to use when strategy is 'fixed' (ct, pet, or ctpet)
                Used to train on specific modalities even if the model supports more
            modes: Available modes for random selection during training
                List of modes that can be randomly selected when training_strategy='random'
            mode_weights: Probability weights for random mode selection
                These values should sum to 1 and match the number of modes
            val_mode: Mode for validation ('all', 'same_as_train', or specific mode)
                - 'all': Validate on all modes (ct, pet, ctpet)
                - 'same_as_train': Use the same mode as training
                - specific mode: Use a specific mode for validation (ct, pet, ctpet)
        """
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.optimizer = optimizer
        self.loss_function = loss_function
        self.lr_scheduler = lr_scheduler
        self.device = device
        self.data_folder = data_folder
        self.amp = amp
        self.val_interval = val_interval
        self.save_interval = save_interval
        self.save_dir = Path(save_dir)
        self.experiment_name = experiment_name
        self.max_epochs = max_epochs
        self.num_classes = num_classes
        self.checkpoint_path = checkpoint_path
        self.sw_batch_size = sw_batch_size
        self.roi_size = roi_size
        self.distributed = distributed
        self.rank = rank
        self.world_size = world_size
        
        # Training strategy parameters
        self.training_strategy = training_strategy
        self.train_mode = train_mode
        self.modes = modes if modes is not None else ["ctpet", "ct", "pet"]
        self.mode_weights = mode_weights if mode_weights is not None else [0.6, 0.2, 0.2]
        self.val_mode = val_mode
        
        # Distributed training attributes
        self.train_sampler = None
        self.val_sampler = None
        
        # Create save directory
        if not self.distributed or self.rank == 0:
            self.save_dir.mkdir(parents=True, exist_ok=True)
        
        # Move model to device
        self.model = self.model.to(self.device)
        
        # Initialize AMP scaler
        self.scaler = GradScaler('cuda') if self.amp else None
        
        # Initialize metrics
        # For overall dice (mean across all classes)
        self.dice_metric = DiceMetric(include_background=False, reduction="mean")
        
        # For per-class dice scores (no reduction)
        self.dice_metric_per_class = DiceMetric(include_background=False, reduction="none")
        
        self.post_pred = AsDiscrete(argmax=True, to_onehot=num_classes)
        self.post_label = AsDiscrete(to_onehot=num_classes)
        
        # Initialize Weights & Biases (only for rank 0)
        self.use_wandb = use_wandb and (not self.distributed or self.rank == 0)
        if self.use_wandb:
            wandb.init(
                project=wandb_project,
                entity=wandb_entity,
                config=wandb_config or {},
                name=experiment_name,
            )
            wandb.watch(self.model)
        
        # Initialize best metric
        self.best_metric = -1
        self.best_metric_epoch = -1
        
        # Initialize epoch
        self.epoch = 0
        
        # Initialize early stopping
        self.patience = 20
        self.early_stopping_counter = 0
        
        # Initialize checkpoint path
        self.checkpoint_path = None
        
    def _check_mode(self, expected_mode):
        """
        Check if the model's mode is set correctly.
        Primarily for debugging mode propagation issues.
        
        Args:
            expected_mode: The mode we expect to be set
        """
        current_mode = "unknown"
        
        # Check top-level model mode
        if hasattr(self.model, "mode"):
            current_mode = self.model.mode
            print(f"Model mode: {current_mode}")
        
        # Check peft_model.base_model.mode
        if hasattr(self.model, "peft_model") and hasattr(self.model.peft_model, "base_model") and hasattr(self.model.peft_model.base_model, "mode"):
            base_mode = self.model.peft_model.base_model.mode
            print(f"Base model mode: {base_mode}")
            
            # Also check swinViT mode
            if hasattr(self.model.peft_model.base_model, "swinViT") and hasattr(self.model.peft_model.base_model.swinViT, "mode"):
                swin_mode = self.model.peft_model.base_model.swinViT.mode
                print(f"SwinViT mode: {swin_mode}")
        
        # Print warning if modes don't match
        if current_mode != "unknown" and current_mode != expected_mode:
            print(f"WARNING: Expected mode {expected_mode}, but model mode is {current_mode}")
            
    def train_epoch(self) -> Dict[str, float]:
        """
        Train for one epoch.
        
        Returns:
            Dictionary with training metrics
        """
        self.model.train()
        epoch_loss = 0
        step = 0
        
        # Set epoch for distributed sampler
        if self.distributed and self.train_sampler is not None:
            self.train_sampler.set_epoch(self.epoch)
        
        # Only show progress bar for rank 0
        if not self.distributed or self.rank == 0:
            progress_bar = tqdm(
                self.train_loader, 
                desc=f"Training Epoch {self.epoch}/{self.max_epochs}"
            )
        else:
            progress_bar = self.train_loader
        
        # Training strategy handling
        if self.training_strategy == 'fixed':
            # Use a fixed mode for training (specified in self.train_mode)
            if hasattr(self.model, "mode"):
                self.model.mode = self.train_mode
                current_mode = self.train_mode
        else:  # Default is 'random'
            # Available modes to train with
            modes = self.modes
            # Weights for each mode
            mode_weights = self.mode_weights
        
        for batch_data in progress_bar:
            step += 1
            inputs, labels = batch_data["image"].to(self.device), batch_data["label"].to(self.device)
            
            # Mode selection for random strategy
            if self.training_strategy == 'random':
                # Randomly select mode based on weights
                if hasattr(self.model, "mode"):
                    current_mode = np.random.choice(modes, p=mode_weights)
                    self.model.mode = current_mode
            
            self.optimizer.zero_grad()
            
            if self.amp:
                with autocast('cuda'):
                    outputs = self.model(inputs)
                    loss = self.loss_function(outputs, labels)
                
                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                outputs = self.model(inputs)
                loss = self.loss_function(outputs, labels)
                loss.backward()
                self.optimizer.step()
            
            epoch_loss += loss.item()
            
            # Update progress bar for rank 0
            if not self.distributed or self.rank == 0:
                if isinstance(progress_bar, tqdm):
                    progress_bar.set_postfix({"loss": loss.item(), "mode": current_mode if hasattr(self.model, "mode") else "unknown"})
        
        # Average loss across all processes for distributed training
        if self.distributed:
            world_size = dist.get_world_size()
            dist.all_reduce(torch.tensor([epoch_loss], device=self.device), op=dist.ReduceOp.SUM)
            epoch_loss /= world_size
        
        epoch_loss /= step
        
        if self.lr_scheduler is not None:
            if isinstance(self.lr_scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                # ReduceLROnPlateau needs validation metrics
                pass
            else:
                self.lr_scheduler.step()
        
        return {"loss": epoch_loss}
    
    def compute_volumes(self, im: sitk.Image) -> Tuple[float, float]:
        """
        Compute the volumes of the GTVp and the GTVn.
        """
        spacing = im.GetSpacing()
        voxvol = spacing[0] * spacing[1] * spacing[2]
        stats = sitk.LabelStatisticsImageFilter()
        stats.Execute(im, im)
        nvoxels1 = stats.GetCount(1)
        nvoxels2 = stats.GetCount(2)
        return nvoxels1 * voxvol, nvoxels2 * voxvol

    def get_intermediate_metrics(self, groundtruth: sitk.Image, prediction: sitk.Image) -> Dict[str, float]:
        """
        Compute intermediate metrics for a given groundtruth and prediction.
        These metrics are used to compute the aggregate dice.
        """
        # Check if sizes match
        if groundtruth.GetSize() != prediction.GetSize():
            raise ValueError(f"Size mismatch: Ground truth {groundtruth.GetSize()} vs Prediction {prediction.GetSize()}")
        
        # Ensure both images are scalar and have the same pixel type
        if groundtruth.GetNumberOfComponentsPerPixel() > 1:
            component_extractor = sitk.VectorIndexSelectionCastImageFilter()
            component_extractor.SetIndex(0)
            groundtruth = component_extractor.Execute(groundtruth)
        
        if prediction.GetNumberOfComponentsPerPixel() > 1:
            component_extractor = sitk.VectorIndexSelectionCastImageFilter()
            component_extractor.SetIndex(0)
            prediction = component_extractor.Execute(prediction)
        
        # Cast to the same pixel type (8-bit unsigned integer)
        groundtruth = sitk.Cast(groundtruth, sitk.sitkUInt8)
        prediction = sitk.Cast(prediction, sitk.sitkUInt8)
        
        overlap_measures = sitk.LabelOverlapMeasuresImageFilter()
        overlap_measures.SetNumberOfThreads(1)
        
        overlap_measures.Execute(groundtruth, prediction)

        DSC1 = overlap_measures.GetDiceCoefficient(1)
        DSC2 = overlap_measures.GetDiceCoefficient(2)

        vol_gt1, vol_gt2 = self.compute_volumes(groundtruth)
        vol_pred1, vol_pred2 = self.compute_volumes(prediction)

        vol_sum1 = vol_gt1 + vol_pred1
        vol_sum2 = vol_gt2 + vol_pred2
        TP1 = DSC1 * (vol_sum1) / 2
        TP2 = DSC2 * (vol_sum2) / 2
        return {
            "TP1": TP1,
            "TP2": TP2,
            "vol_sum1": vol_sum1,
            "vol_sum2": vol_sum2,
        }

    def compute_agg_dice(self, intermediate_results: List[Dict[str, float]]) -> Dict[str, float]:
        """
        Compute the aggregate dice score from the intermediate results.
        """
        TP1s = [v["TP1"] for v in intermediate_results]
        TP2s = [v["TP2"] for v in intermediate_results]
        vol_sum1s = [v["vol_sum1"] for v in intermediate_results]
        vol_sum2s = [v["vol_sum2"] for v in intermediate_results]
        DSCagg1 = 2 * np.sum(TP1s) / np.sum(vol_sum1s) if np.sum(vol_sum1s) > 0 else 0.0
        DSCagg2 = 2 * np.sum(TP2s) / np.sum(vol_sum2s) if np.sum(vol_sum2s) > 0 else 0.0
        return {
            'GTVp': DSCagg1,
            'GTVn': DSCagg2,
            'mean': np.mean([DSCagg1, DSCagg2])
        }

    def validate(self) -> Dict[str, float]:
        """
        Validate the model according to the validation mode setting.
        
        Returns:
            Dictionary with validation metrics for the specified mode(s)
        """
        self.model.eval()
        
        # Set epoch for distributed sampler
        if self.distributed and self.val_sampler is not None:
            self.val_sampler.set_epoch(self.epoch)
        
        # Only show progress bar for rank 0
        if not self.distributed or self.rank == 0:
            progress_bar = tqdm(
                self.val_loader, 
                desc=f"Validation Epoch {self.epoch}/{self.max_epochs}"
            )
        else:
            progress_bar = self.val_loader
        
        # Determine which modes to validate on
        if self.val_mode == 'all':
            # Validate with all three modes
            validation_modes = ["ctpet", "ct", "pet"]
        elif self.val_mode == 'same_as_train':
            # Use the current training mode
            if self.training_strategy == 'fixed':
                validation_modes = [self.train_mode]
            else:
                # Default to ctpet if using random strategy
                validation_modes = ["ctpet"]
        else:
            # Use the specified validation mode
            validation_modes = [self.val_mode]
        
        # Run validation with the selected modes
        metrics_by_mode = {}
        
        # Store the original mode of the model
        if hasattr(self.model, "mode"):
            original_mode = self.model.mode
        else:
            original_mode = "ctpet"
        
        # Validate with each selected mode
        for mode in validation_modes:
            # Set model mode
            if hasattr(self.model, "mode"):
                self.model.mode = mode
            
            if not self.distributed or self.rank == 0:
                print(f"Validating with mode: {mode}")
            
            # Run validation for this mode
            metrics_by_mode[mode] = self._validate_single_mode(progress_bar, mode)
        
        # Restore original mode
        if hasattr(self.model, "mode"):
            self.model.mode = original_mode
        
        # Combine results from all modes into a single dictionary
        combined_metrics = {}
        for mode, metrics in metrics_by_mode.items():
            for metric_name, metric_value in metrics.items():
                combined_metrics[f"{mode}_{metric_name}"] = metric_value
        
        # For backwards compatibility, add the ctpet metrics without prefix if it was validated
        if "ctpet" in metrics_by_mode:
            for metric_name, metric_value in metrics_by_mode["ctpet"].items():
                combined_metrics[metric_name] = metric_value
        
        return combined_metrics
        
    def _validate_single_mode(self, progress_bar, mode) -> Dict[str, float]:
        """
        Validate the model for a single mode.
        
        Args:
            progress_bar: Progress bar for validation
            mode: Mode to validate with (ctpet, ct, or pet)
            
        Returns:
            Dictionary with validation metrics for this mode
        """
        # Check the model's mode for debugging
        if not self.distributed or self.rank == 0:
            self._check_mode(mode)
        
        # Create a fresh iterator for validation
        val_loader = self.val_loader
        
        # Only show progress bar for rank 0
        if not self.distributed or self.rank == 0:
            progress_bar = tqdm(
                val_loader, 
                desc=f"Validating with {mode} mode"
            )
        else:
            progress_bar = val_loader
        
        intermediate_results = []  # For aggregate Dice
        
        with torch.no_grad():
            for batch_data in progress_bar:
                inputs, labels = batch_data["image"].to(self.device), batch_data["label"].to(self.device)
                
                # Sliding window inference
                outputs = sliding_window_inference(
                    inputs, 
                    self.roi_size, 
                    self.sw_batch_size, 
                    self.model,
                    overlap=0.5,
                )
                
                # Decollate batch - split batch into individual samples
                labels_list = decollate_batch(labels)
                outputs_list = decollate_batch(outputs)
                
                # Apply post-processing to each sample
                labels_convert = [self.post_label(label) for label in labels_list]
                outputs_convert = [self.post_pred(output) for output in outputs_list]
                
                # Compute MONAI Dice metrics
                self.dice_metric(y_pred=outputs_convert, y=labels_convert)
                self.dice_metric_per_class(y_pred=outputs_convert, y=labels_convert)

                # Compute Aggregate Dice metrics
                for i, (label, output) in enumerate(zip(labels_list, outputs_list)):
                    # Convert to numpy and then to SimpleITK images
                    label_np = label.cpu().numpy().astype(np.uint8)
                    pred_np = output.argmax(dim=0).cpu().numpy().astype(np.uint8)
                    
                    # SimpleITK expects dimensions in (z, y, x) order, but PyTorch typically uses (c, z, y, x) or (z, y, x)
                    # Remove channel dimension if present
                    if len(label_np.shape) > 3:
                        label_np = np.squeeze(label_np, axis=0)  # Remove channel dimension
                    
                    # Ensure arrays are 3D
                    if len(label_np.shape) == 2:
                        label_np = np.expand_dims(label_np, axis=0)  # Add z dimension
                    if len(pred_np.shape) == 2:
                        pred_np = np.expand_dims(pred_np, axis=0)  # Add z dimension
                    
                    # Transpose arrays to match SimpleITK's expected order (z, y, x)
                    # PyTorch typically uses (z, y, x) but sometimes the dimensions might be in a different order
                    # Make sure the largest dimension (310) is the z dimension for SimpleITK
                    if label_np.shape[2] > label_np.shape[0]:  # If depth (310) is the last dimension
                        label_np = np.transpose(label_np, (2, 1, 0))
                    if pred_np.shape[2] > pred_np.shape[0]:  # If depth (310) is the last dimension
                        pred_np = np.transpose(pred_np, (2, 1, 0))
                    
                    # Create SimpleITK images - ensure they're scalar images, not vector images
                    label_sitk = sitk.GetImageFromArray(label_np, isVector=False)
                    pred_sitk = sitk.GetImageFromArray(pred_np, isVector=False)
                    
                    # Get patient ID and ground truth file for metadata
                    patient_id = batch_data['patient_id'][i] if isinstance(batch_data['patient_id'], list) else batch_data['patient_id']
                    data_folder = self.data_folder  # Hardcoded for now; adjust as needed
                    
                    # More robust ground truth file lookup
                    try:
                        gt_files = list(Path(data_folder).rglob(f'{patient_id}*_gt.nii.gz'))
                        if not gt_files:
                            if not self.distributed or self.rank == 0:
                                print(f"Warning: No ground truth file found for patient {patient_id}")
                            continue
                        gt_file = gt_files[0]
                        groundtruth = sitk.ReadImage(str(gt_file.resolve()), imageIO="NiftiImageIO")
                        
                        # Ensure ground truth is a scalar image, not a vector image
                        if groundtruth.GetNumberOfComponentsPerPixel() > 1:
                            # Convert vector image to scalar by taking the first component
                            component_extractor = sitk.VectorIndexSelectionCastImageFilter()
                            component_extractor.SetIndex(0)
                            groundtruth = component_extractor.Execute(groundtruth)
                    except Exception as e:
                        if not self.distributed or self.rank == 0:
                            print(f"Error loading ground truth for patient {patient_id}: {e}")
                        continue
                    
                    # Set metadata from ground truth file
                    label_sitk.SetSpacing(groundtruth.GetSpacing())
                    label_sitk.SetOrigin(groundtruth.GetOrigin())
                    label_sitk.SetDirection(groundtruth.GetDirection())
                    pred_sitk.SetSpacing(groundtruth.GetSpacing())
                    pred_sitk.SetOrigin(groundtruth.GetOrigin())
                    pred_sitk.SetDirection(groundtruth.GetDirection())
                    
                    # Check if sizes match with ground truth
                    if label_sitk.GetSize() != groundtruth.GetSize() or pred_sitk.GetSize() != groundtruth.GetSize():
                        # Try to resample to match ground truth dimensions
                        try:
                            # Create resampler
                            resampler = sitk.ResampleImageFilter()
                            resampler.SetReferenceImage(groundtruth)
                            resampler.SetInterpolator(sitk.sitkNearestNeighbor)  # Use nearest neighbor for label images
                            
                            # Resample label and prediction
                            if label_sitk.GetSize() != groundtruth.GetSize():
                                label_sitk = resampler.Execute(label_sitk)
                            
                            if pred_sitk.GetSize() != groundtruth.GetSize():
                                pred_sitk = resampler.Execute(pred_sitk)
                        except Exception as e:
                            if not self.distributed or self.rank == 0:
                                print(f"Error resampling images for patient {patient_id}: {e}")
                            continue
                    
                    # Compute intermediate metrics
                    try:
                        metrics = self.get_intermediate_metrics(label_sitk, pred_sitk)
                        intermediate_results.append(metrics)
                    except Exception as e:
                        if not self.distributed or self.rank == 0:
                            print(f"Error computing metrics for patient {patient_id}: {e}")
            
            # Aggregate MONAI Dice metrics
            overall_dice = self.dice_metric.aggregate().item()
            per_class_dice = self.dice_metric_per_class.aggregate()
            
            # Reset MONAI Dice metrics
            self.dice_metric.reset()
            self.dice_metric_per_class.reset()
            
            # Extract class-specific MONAI Dice scores
            if len(per_class_dice.shape) > 0:
                per_class_dice_no_nan = torch.nan_to_num(per_class_dice, nan=0.0)
                mean_per_class_dice = torch.mean(per_class_dice_no_nan, dim=0)
                tumor_dice = mean_per_class_dice[0].item() if mean_per_class_dice.shape[0] >= 1 else 0.0
                lymph_node_dice = mean_per_class_dice[1].item() if mean_per_class_dice.shape[0] >= 2 else 0.0
            else:
                tumor_dice = 0.0
                lymph_node_dice = 0.0

            # Compute Aggregate Dice
            agg_dice = self.compute_agg_dice(intermediate_results)
        
        # Synchronize metrics across processes for distributed training
        if self.distributed:
            metrics_tensor = torch.tensor([
                overall_dice, tumor_dice, lymph_node_dice,
                agg_dice['GTVp'], agg_dice['GTVn']
            ], device=self.device)
            
            dist.all_reduce(metrics_tensor, op=dist.ReduceOp.SUM)
            metrics_tensor /= dist.get_world_size()
            
            overall_dice = metrics_tensor[0].item()
            tumor_dice = metrics_tensor[1].item()
            lymph_node_dice = metrics_tensor[2].item()
            agg_dice['GTVp'] = metrics_tensor[3].item()
            agg_dice['GTVn'] = metrics_tensor[4].item()
            agg_dice['mean'] = np.mean([agg_dice['GTVp'], agg_dice['GTVn']])
        
        return {
            "dice": overall_dice,
            "tumor_dice": tumor_dice,
            "lymph_node_dice": lymph_node_dice,
            "agg_dice_gtvp": agg_dice['GTVp'],
            "agg_dice_gtvn": agg_dice['GTVn'],
            "agg_dice_mean": agg_dice['mean']
        }
    
    def save_checkpoint(self, is_best: bool = False) -> None:
        """
        Save a checkpoint of the model.
        
        Args:
            is_best: Whether this is the best model so far
        """
        # Only save checkpoints from rank 0
        if self.distributed and self.rank != 0:
            return
        
        # Determine if the model is a PEFT model
        is_peft_model = hasattr(self.model, "save_pretrained") or (hasattr(self.model, "module") and hasattr(self.model.module, "save_pretrained"))
        
        if is_peft_model:
            # Save PEFT model using save_pretrained
            if not self.distributed or self.rank == 0:
                print(f"Saving PEFT model checkpoint...")
                
            # Create directory for saving
            checkpoint_dir = self.save_dir / "peft_model"
            if is_best:
                checkpoint_dir = self.save_dir / "peft_model_best"
            
                # Make sure the directory exists
                os.makedirs(checkpoint_dir, exist_ok=True)
                
                # Get the actual model to save (unwrap from DDP if needed)
                if hasattr(self.model, "module"):
                    model_to_save = self.model.module
                else:
                    model_to_save = self.model
                    
                # Use save_pretrained to properly save the PEFT model
                model_to_save.save_pretrained(checkpoint_dir)
                
                # Also save optimizer and scheduler states
                optimizer_path = checkpoint_dir / "optimizer.pt"
                torch.save(self.optimizer.state_dict(), optimizer_path)
                
                if self.lr_scheduler is not None:
                    scheduler_path = checkpoint_dir / "scheduler.pt"
                    torch.save(self.lr_scheduler.state_dict(), scheduler_path)
                
                # Save training metadata
                metadata = {
                    "epoch": self.epoch,
                    "best_metric": self.best_metric,
                    "best_metric_epoch": self.best_metric_epoch,
                    "training_strategy": self.training_strategy,
                    "train_mode": self.train_mode
                }
                
                metadata_path = checkpoint_dir / "training_metadata.pt"
                torch.save(metadata, metadata_path)
                
                if not self.distributed or self.rank == 0:
                    suffix = "best" if is_best else "last"
                    print(f"Successfully saved PEFT model checkpoint ({suffix}) to {checkpoint_dir}")
                
                print("Regular checkpoint saving...")
                self._save_regular_checkpoint(is_best)
        else:
            # For regular models, use the standard PyTorch saving method
            self._save_regular_checkpoint(is_best)
    
    def _save_regular_checkpoint(self, is_best: bool = False) -> None:
        """
        Save a regular (non-PEFT) checkpoint of the model.
        
        Args:
            is_best: Whether this is the best model so far
        """
        # Get state dict from the model (handle DDP wrapper)
        if hasattr(self.model, "module"):
            model_state_dict = self.model.module.state_dict()
        else:
            model_state_dict = self.model.state_dict()
        
        # Get current model mode
        current_mode = None
        if hasattr(self.model, "mode"):
            current_mode = self.model.mode
        elif hasattr(self.model, "module") and hasattr(self.model.module, "mode"):
            current_mode = self.model.module.mode
        
        checkpoint = {
            "epoch": self.epoch,
            "model_state_dict": model_state_dict,
            "optimizer_state_dict": self.optimizer.state_dict(),
            "best_metric": self.best_metric,
            "best_metric_epoch": self.best_metric_epoch,
            # Save training strategy info
            "training_strategy": self.training_strategy,
            "train_mode": self.train_mode,
            "current_mode": current_mode,
        }
        
        if self.lr_scheduler is not None:
            checkpoint["scheduler_state_dict"] = self.lr_scheduler.state_dict()
        
        # Save last checkpoint
        last_path = self.save_dir / f"{self.experiment_name}_last.pt"
        torch.save(checkpoint, last_path)
        
        # Save best checkpoint
        if is_best:
            best_path = self.save_dir / f"{self.experiment_name}_best.pt"
            torch.save(checkpoint, best_path)
    
    
    def train(self) -> Dict[str, List[float]]:
        """
        Train the model for the specified number of epochs.
        
        Returns:
            Dictionary with training history
        """
        # Initialize history
        history = {
            "train_loss": [],
            "val_dice": [],
            "val_tumor_dice": [],
            "val_lymph_node_dice": [],
            "learning_rate": [],
        }
        
        
        # Training loop
        for self.epoch in range(self.epoch, self.max_epochs):
            # Make sure samplers are set for this epoch in distributed training
            if self.distributed:
                if hasattr(self, 'train_sampler') and self.train_sampler is not None:
                    self.train_sampler.set_epoch(self.epoch)
                if hasattr(self, 'val_sampler') and self.val_sampler is not None:
                    self.val_sampler.set_epoch(self.epoch)
            
            # Train for one epoch
            train_metrics = self.train_epoch()
            history["train_loss"].append(train_metrics["loss"])
            
            # Get current learning rate
            current_lr = self.optimizer.param_groups[0]["lr"]
            history["learning_rate"].append(current_lr)
            
            # Log to Weights & Biases
            if self.use_wandb:
                wandb.log({
                    "train_loss": train_metrics["loss"],
                    "learning_rate": current_lr,
                    "epoch": self.epoch,
                })
            
            # Validate
            if (self.epoch + 1) % self.val_interval == 0:
                val_metrics = self.validate()
                history["val_dice"].append(val_metrics["dice"])
                history["val_tumor_dice"].append(val_metrics["tumor_dice"])
                history["val_lymph_node_dice"].append(val_metrics["lymph_node_dice"])
                
                # Log to Weights & Biases
                if self.use_wandb:
                    wandb_log = {
                        "epoch": self.epoch,
                        # ctpet metrics (both with and without prefix for backwards compatibility)
                        "val_dice": val_metrics["dice"],
                        "val_tumor_dice": val_metrics["tumor_dice"],
                        "val_lymph_node_dice": val_metrics["lymph_node_dice"],
                        "val_agg_dice_gtvp": val_metrics["agg_dice_gtvp"],
                        "val_agg_dice_gtvn": val_metrics["agg_dice_gtvn"],
                        "val_agg_dice_mean": val_metrics["agg_dice_mean"],
                        
                        # Prefixed metrics for all modes
                        "val_ctpet_dice": val_metrics["ctpet_dice"],
                        "val_ctpet_tumor_dice": val_metrics["ctpet_tumor_dice"],
                        "val_ctpet_lymph_node_dice": val_metrics["ctpet_lymph_node_dice"],
                        "val_ctpet_agg_dice_gtvp": val_metrics["ctpet_agg_dice_gtvp"],
                        "val_ctpet_agg_dice_gtvn": val_metrics["ctpet_agg_dice_gtvn"],
                        "val_ctpet_agg_dice_mean": val_metrics["ctpet_agg_dice_mean"],
                        
                        "val_ct_dice": val_metrics["ct_dice"],
                        "val_ct_tumor_dice": val_metrics["ct_tumor_dice"],
                        "val_ct_lymph_node_dice": val_metrics["ct_lymph_node_dice"],
                        "val_ct_agg_dice_gtvp": val_metrics["ct_agg_dice_gtvp"],
                        "val_ct_agg_dice_gtvn": val_metrics["ct_agg_dice_gtvn"],
                        "val_ct_agg_dice_mean": val_metrics["ct_agg_dice_mean"],
                        
                        "val_pet_dice": val_metrics["pet_dice"],
                        "val_pet_tumor_dice": val_metrics["pet_tumor_dice"],
                        "val_pet_lymph_node_dice": val_metrics["pet_lymph_node_dice"],
                        "val_pet_agg_dice_gtvp": val_metrics["pet_agg_dice_gtvp"],
                        "val_pet_agg_dice_gtvn": val_metrics["pet_agg_dice_gtvn"],
                        "val_pet_agg_dice_mean": val_metrics["pet_agg_dice_mean"],
                    }
                    wandb.log(wandb_log)
                
                # Check if this is the best model (using ctpet_agg_dice_mean)
                # For backward compatibility we use both agg_dice_mean and ctpet_agg_dice_mean
                current_metric = val_metrics["ctpet_agg_dice_mean"]
                if current_metric > self.best_metric:
                    self.best_metric = current_metric
                    self.best_metric_epoch = self.epoch
                    self.save_checkpoint(is_best=True)
                    self.early_stopping_counter = 0
                else:
                    self.early_stopping_counter += 1
                
                # Print metrics (only for rank 0)
                if not self.distributed or self.rank == 0:
                    print(
                        f"Epoch {self.epoch}/{self.max_epochs} - Train Loss: {train_metrics['loss']:.4f}"
                    )
                    print(
                        f"CT+PET Mode - "
                        f"Dice: {val_metrics['ctpet_dice']:.4f}, "
                        f"Tumor: {val_metrics['ctpet_tumor_dice']:.4f}, "
                        f"Lymph: {val_metrics['ctpet_lymph_node_dice']:.4f}, "
                        f"Agg GTVp: {val_metrics['ctpet_agg_dice_gtvp']:.4f}, "
                        f"Agg GTVn: {val_metrics['ctpet_agg_dice_gtvn']:.4f}, "
                        f"Agg Mean: {val_metrics['ctpet_agg_dice_mean']:.4f}"
                    )
                    print(
                        f"CT Mode - "
                        f"Dice: {val_metrics['ct_dice']:.4f}, "
                        f"Tumor: {val_metrics['ct_tumor_dice']:.4f}, "
                        f"Lymph: {val_metrics['ct_lymph_node_dice']:.4f}, "
                        f"Agg GTVp: {val_metrics['ct_agg_dice_gtvp']:.4f}, "
                        f"Agg GTVn: {val_metrics['ct_agg_dice_gtvn']:.4f}, "
                        f"Agg Mean: {val_metrics['ct_agg_dice_mean']:.4f}"
                    )
                    print(
                        f"PET Mode - "
                        f"Dice: {val_metrics['pet_dice']:.4f}, "
                        f"Tumor: {val_metrics['pet_tumor_dice']:.4f}, "
                        f"Lymph: {val_metrics['pet_lymph_node_dice']:.4f}, "
                        f"Agg GTVp: {val_metrics['pet_agg_dice_gtvp']:.4f}, "
                        f"Agg GTVn: {val_metrics['pet_agg_dice_gtvn']:.4f}, "
                        f"Agg Mean: {val_metrics['pet_agg_dice_mean']:.4f}"
                    )
                    print(
                        f"Best CT+PET Agg Dice Mean: {self.best_metric:.4f} at Epoch {self.best_metric_epoch}"
                    )
                
                # Update learning rate for ReduceLROnPlateau
                if isinstance(self.lr_scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.lr_scheduler.step(val_metrics["ctpet_agg_dice_mean"])  # Use ctpet_agg_dice_mean for LR scheduler
                
                # Early stopping
                if self.early_stopping_counter >= self.patience:
                    if not self.distributed or self.rank == 0:
                        print(f"Early stopping triggered after {self.epoch + 1} epochs")
                    break
            else:
                # Print training metrics (only for rank 0)
                if not self.distributed or self.rank == 0:
                    print(
                        f"Epoch {self.epoch}/{self.max_epochs} - "
                        f"Train Loss: {train_metrics['loss']:.4f}, "
                        f"Learning Rate: {current_lr:.6f}"
                    )
            
            # Save checkpoint after each epoch (will overwrite the last checkpoint)
            self.save_checkpoint()
        
        # Save the final checkpoint and print completion messages (only for rank 0)
        if not self.distributed or self.rank == 0:
            print(f"Training completed after {self.epoch} epochs")
            print(f"Training completed. Best CT+PET Agg Dice Mean: {self.best_metric:.4f} at Epoch {self.best_metric_epoch}")
        
        # Close Weights & Biases
        if self.use_wandb:
            wandb.finish()
        
        return history


def get_trainer(
    model: nn.Module,
    train_loader: torch.utils.data.DataLoader,
    val_loader: torch.utils.data.DataLoader,
    config: Dict,
) -> Trainer:
    """
    Factory function to create a trainer.
    
    Args:
        model: Model to train
        train_loader: Training data loader
        val_loader: Validation data loader
        config: Configuration dictionary
        
    Returns:
        Initialized trainer
    """
    # Get optimizer
    optimizer_name = config.get("optimizer", "adam").lower()
    lr = config.get("learning_rate", 1e-4)
    weight_decay = config.get("weight_decay", 1e-5)
    
    if optimizer_name == "adam":
        optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    elif optimizer_name == "adamw":
        optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    elif optimizer_name == "lamb":
        optimizer = torch_optimizer.Lamb(model.parameters(), lr=lr, betas=(0.9, 0.999), weight_decay=weight_decay)
    elif optimizer_name == "sgd":
        momentum = config.get("momentum", 0.9)
        optimizer = optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)
    else:
        raise ValueError(f"Unsupported optimizer: {optimizer_name}")
    
    # Get loss function
    loss_name = config.get("loss", "dice_ce").lower()
    num_classes = config.get("num_classes", 3)  # Default to 3 classes
    
    if loss_name == "dice":
        loss_function = DiceLoss(to_onehot_y=True, softmax=True)
    elif loss_name == "dice_ce":
        loss_function = DiceCELoss(to_onehot_y=True, softmax=True)
    elif loss_name == "dice_focal":
        loss_function = DiceFocalLoss(to_onehot_y=True, softmax=True)
    else:
        raise ValueError(f"Unsupported loss function: {loss_name}")
    
    # Get learning rate scheduler
    scheduler_name = config.get("scheduler", "cosine").lower()
    max_epochs = config.get("max_epochs", 100)
    
    if scheduler_name == "cosine":
        lr_scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max_epochs)
    elif scheduler_name == "step":
        step_size = config.get("step_size", 30)
        gamma = config.get("gamma", 0.1)
        lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=gamma)
    elif scheduler_name == "reduce_on_plateau":
        factor = config.get("factor", 0.1)
        patience = config.get("scheduler_patience", 5)
        lr_scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="max", factor=factor, patience=patience, verbose=True
        )
    elif scheduler_name == "none":
        lr_scheduler = None
    else:
        raise ValueError(f"Unsupported scheduler: {scheduler_name}")
    
    # Get distributed training parameters
    distributed = config.get("distributed", False)
    rank = config.get("rank", 0)
    world_size = config.get("world_size", 1)
    device = config.get("device", "cuda")
    
    # Create trainer
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        optimizer=optimizer,
        loss_function=loss_function,
        lr_scheduler=lr_scheduler,
        device=device,
        data_folder=config.get("data_dir", "./dataset/hecktor"),
        amp=config.get("amp", False),
        val_interval=config.get("val_interval", 1),
        save_interval=config.get("save_interval", 10),
        save_dir=config.get("save_dir", "./checkpoints"),
        experiment_name=config.get("experiment_name", "swin_unetr"),
        max_epochs=max_epochs,
        num_classes=num_classes,
        sw_batch_size=config.get("sw_batch_size", 4),
        roi_size=config.get("roi_size", (96, 96, 96)),
        use_wandb=config.get("use_wandb", False),
        wandb_project=config.get("wandb_project", "media2025"),
        wandb_entity=config.get("wandb_entity", None),
        wandb_config=config,
        distributed=distributed,
        rank=rank,
        world_size=world_size,
        checkpoint_path=config.get("checkpoint_path", None),
        training_strategy=config.get("training_strategy", "random"),
        train_mode=config.get("train_mode", "ctpet"),
        modes=config.get("modes", None),
        mode_weights=config.get("mode_weights", None),
        val_mode=config.get("val_mode", "all"),
    )
    
    return trainer