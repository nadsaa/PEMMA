import os
import numpy as np
import SimpleITK as sitk
from pathlib import Path
from tqdm import tqdm
from monai.transforms import LoadImaged, EnsureChannelFirstd
from monai.data import MetaTensor

def analyze_image(file_path):
    """Analyze a single image file."""
    img = sitk.ReadImage(str(file_path))
    size = img.GetSize()
    spacing = img.GetSpacing()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    metadata = {}
    
    # Get all metadata keys
    for key in img.GetMetaDataKeys():
        metadata[key] = img.GetMetaData(key)
    
    return size, spacing, origin, direction, metadata

def test_monai_transforms(file_path):
    """Test MONAI transforms on a single image."""
    data = {"image": str(file_path)}
    
    # Create transforms
    load_transform = LoadImaged(keys=["image"])
    channel_transform = EnsureChannelFirstd(keys=["image"])
    
    # Apply transforms
    try:
        # Load image
        loaded = load_transform(data)
        loaded_shape = loaded["image"].shape
        
        # Ensure channel first
        channeled = channel_transform(loaded)
        channeled_shape = channeled["image"].shape
        
        # Check if it's a MetaTensor
        is_metatensor = isinstance(channeled["image"], MetaTensor)
        
        return {
            "success": True,
            "loaded_shape": loaded_shape,
            "channeled_shape": channeled_shape,
            "is_metatensor": is_metatensor
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

def main():
    data_dir = Path("./dataset/hecktor")
    
    # Initialize lists to store results
    ct_sizes = []
    ct_spacings = []
    ct_origins = []
    ct_directions = []
    ct_metadata = []
    ct_monai_results = []
    
    pet_sizes = []
    pet_spacings = []
    pet_origins = []
    pet_directions = []
    pet_metadata = []
    pet_monai_results = []
    
    mask_sizes = []
    mask_spacings = []
    mask_origins = []
    mask_directions = []
    mask_metadata = []
    mask_monai_results = []
    
    # Get all patient IDs
    patient_ids = sorted([f.name.split('_')[0] for f in data_dir.glob("*_ct.nii.gz")])
    
    print(f"Found {len(patient_ids)} patients")
    
    for patient_id in tqdm(patient_ids):
        # Analyze CT
        ct_file = data_dir / f"{patient_id}_ct.nii.gz"
        if ct_file.exists():
            size, spacing, origin, direction, metadata = analyze_image(ct_file)
            ct_sizes.append(size)
            ct_spacings.append(spacing)
            ct_origins.append(origin)
            ct_directions.append(direction)
            ct_metadata.append(metadata)
            ct_monai_results.append(test_monai_transforms(ct_file))
        
        # Analyze PET
        pet_file = data_dir / f"{patient_id}_pet.nii.gz"
        if pet_file.exists():
            size, spacing, origin, direction, metadata = analyze_image(pet_file)
            pet_sizes.append(size)
            pet_spacings.append(spacing)
            pet_origins.append(origin)
            pet_directions.append(direction)
            pet_metadata.append(metadata)
            pet_monai_results.append(test_monai_transforms(pet_file))
        
        # Analyze mask
        mask_file = data_dir / f"{patient_id}_gt.nii.gz"
        if mask_file.exists():
            size, spacing, origin, direction, metadata = analyze_image(mask_file)
            mask_sizes.append(size)
            mask_spacings.append(spacing)
            mask_origins.append(origin)
            mask_directions.append(direction)
            mask_metadata.append(metadata)
            mask_monai_results.append(test_monai_transforms(mask_file))
    
    # Convert to numpy arrays for easier analysis
    ct_sizes = np.array(ct_sizes)
    ct_spacings = np.array(ct_spacings)
    ct_origins = np.array(ct_origins)
    ct_directions = np.array(ct_directions)
    
    pet_sizes = np.array(pet_sizes)
    pet_spacings = np.array(pet_spacings)
    pet_origins = np.array(pet_origins)
    pet_directions = np.array(pet_directions)
    
    mask_sizes = np.array(mask_sizes)
    mask_spacings = np.array(mask_spacings)
    mask_origins = np.array(mask_origins)
    mask_directions = np.array(mask_directions)
    
    print("\nAnalysis Results:")
    print("\nCT Images:")
    print(f"Size (min): {ct_sizes.min(axis=0)}")
    print(f"Size (max): {ct_sizes.max(axis=0)}")
    print(f"Size (mean): {ct_sizes.mean(axis=0)}")
    print(f"Spacing (min): {ct_spacings.min(axis=0)}")
    print(f"Spacing (max): {ct_spacings.max(axis=0)}")
    print(f"Spacing (mean): {ct_spacings.mean(axis=0)}")
    print(f"Origin (min): {ct_origins.min(axis=0)}")
    print(f"Origin (max): {ct_origins.max(axis=0)}")
    print(f"Origin (mean): {ct_origins.mean(axis=0)}")
    print(f"Direction (unique): {np.unique(ct_directions, axis=0)}")
    
    print("\nPET Images:")
    print(f"Size (min): {pet_sizes.min(axis=0)}")
    print(f"Size (max): {pet_sizes.max(axis=0)}")
    print(f"Size (mean): {pet_sizes.mean(axis=0)}")
    print(f"Spacing (min): {pet_spacings.min(axis=0)}")
    print(f"Spacing (max): {pet_spacings.max(axis=0)}")
    print(f"Spacing (mean): {pet_spacings.mean(axis=0)}")
    print(f"Origin (min): {pet_origins.min(axis=0)}")
    print(f"Origin (max): {pet_origins.max(axis=0)}")
    print(f"Origin (mean): {pet_origins.mean(axis=0)}")
    print(f"Direction (unique): {np.unique(pet_directions, axis=0)}")
    
    print("\nMask Images:")
    print(f"Size (min): {mask_sizes.min(axis=0)}")
    print(f"Size (max): {mask_sizes.max(axis=0)}")
    print(f"Size (mean): {mask_sizes.mean(axis=0)}")
    print(f"Spacing (min): {mask_spacings.min(axis=0)}")
    print(f"Spacing (max): {mask_spacings.max(axis=0)}")
    print(f"Spacing (mean): {mask_spacings.mean(axis=0)}")
    print(f"Origin (min): {mask_origins.min(axis=0)}")
    print(f"Origin (max): {mask_origins.max(axis=0)}")
    print(f"Origin (mean): {mask_origins.mean(axis=0)}")
    print(f"Direction (unique): {np.unique(mask_directions, axis=0)}")
    
    # Check metadata keys
    if ct_metadata:
        print("\nCT Metadata Keys:")
        print(sorted(list(ct_metadata[0].keys())))
    if pet_metadata:
        print("\nPET Metadata Keys:")
        print(sorted(list(pet_metadata[0].keys())))
    if mask_metadata:
        print("\nMask Metadata Keys:")
        print(sorted(list(mask_metadata[0].keys())))
    
    # Check MONAI transform results
    print("\nMONAI Transform Results:")
    
    # CT results
    ct_success = sum(1 for r in ct_monai_results if r["success"])
    if ct_success > 0:
        print(f"\nCT Images:")
        print(f"Successfully processed: {ct_success}/{len(ct_monai_results)}")
        print(f"Sample shapes after loading: {ct_monai_results[0]['loaded_shape']}")
        print(f"Sample shapes after channeling: {ct_monai_results[0]['channeled_shape']}")
        print(f"Is MetaTensor: {ct_monai_results[0]['is_metatensor']}")
    else:
        print("\nCT Images failed to process with MONAI transforms")
        print(f"Error: {ct_monai_results[0]['error']}")
    
    # PET results
    pet_success = sum(1 for r in pet_monai_results if r["success"])
    if pet_success > 0:
        print(f"\nPET Images:")
        print(f"Successfully processed: {pet_success}/{len(pet_monai_results)}")
        print(f"Sample shapes after loading: {pet_monai_results[0]['loaded_shape']}")
        print(f"Sample shapes after channeling: {pet_monai_results[0]['channeled_shape']}")
        print(f"Is MetaTensor: {pet_monai_results[0]['is_metatensor']}")
    else:
        print("\nPET Images failed to process with MONAI transforms")
        print(f"Error: {pet_monai_results[0]['error']}")
    
    # Mask results
    mask_success = sum(1 for r in mask_monai_results if r["success"])
    if mask_success > 0:
        print(f"\nMask Images:")
        print(f"Successfully processed: {mask_success}/{len(mask_monai_results)}")
        print(f"Sample shapes after loading: {mask_monai_results[0]['loaded_shape']}")
        print(f"Sample shapes after channeling: {mask_monai_results[0]['channeled_shape']}")
        print(f"Is MetaTensor: {mask_monai_results[0]['is_metatensor']}")
    else:
        print("\nMask Images failed to process with MONAI transforms")
        print(f"Error: {mask_monai_results[0]['error']}")

if __name__ == "__main__":
    main() 