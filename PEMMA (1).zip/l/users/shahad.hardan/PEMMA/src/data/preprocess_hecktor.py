#!/usr/bin/env python
# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Preprocessing script for HECKTOR dataset using SimpleITK.
This script loads CT, PET, and ground truth images, resamples them to 1x1x1 mm spacing,
crops the head and neck region centered on tumors, and saves the processed images.
"""

import os
import argparse
import json
import logging
import numpy as np
import SimpleITK as sitk
from pathlib import Path
from tqdm import tqdm
import multiprocessing as mp
from functools import partial

# Set up logging
def setup_logging(output_dir):
    log_file = os.path.join(output_dir, "preprocessing_edge_cases.log")
    
    # Create logger
    logger = logging.getLogger("hecktor_preprocessing")
    logger.setLevel(logging.INFO)
    
    # Create file handler
    fh = logging.FileHandler(log_file)
    fh.setLevel(logging.INFO)
    
    # Create console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    
    # Add handlers to logger
    logger.addHandler(fh)
    logger.addHandler(ch)
    
    return logger


def prepare_datalist(data_dir, label_dir, centers=None):
    """
    Prepare datalist for dataset creation from the HECKTOR dataset.
    
    Args:
        data_dir: Base directory containing CT and PET images
        label_dir: Directory containing label masks
        centers: List of centers to include (e.g., ["CHUM", "CHUS"])
        
    Returns:
        List of dictionaries with paths to CT, PET, and label files
    """
    data_dir = Path(data_dir)
    label_dir = Path(label_dir)
    
    print(f"\nDiagnostic information:")
    print(f"Data directory: {data_dir}")
    print(f"Label directory: {label_dir}")
    
    # Get all CT files (pattern: PATIENT-ID__CT.nii.gz)
    ct_files = sorted(list(data_dir.glob("*__CT.nii.gz")))
    print(f"Found {len(ct_files)} CT files")
    
    # Create datalist entries
    datalist = []
    missing_pet = []
    missing_label = []
    
    for ct_file in ct_files:
        # Extract patient ID (CHUM-001, etc.)
        patient_id = ct_file.name.split("__")[0]  # Split on double underscore
        
        # Extract center
        center = patient_id.split("-")[0]
        
        # Skip if center not in centers list
        if centers is not None and center not in centers:
            continue
        
        # Find corresponding PET file (pattern: PATIENT-ID__PT.nii.gz)
        pet_file = data_dir / f"{patient_id}__PT.nii.gz"  # PT not PET
        
        # Find corresponding label file (pattern: PATIENT-ID.nii.gz)
        label_file = label_dir / f"{patient_id}.nii.gz"
        
        # Check if all required files exist
        if not pet_file.exists():
            print(f"Warning: PET file not found for {patient_id}")
            missing_pet.append(patient_id)
            continue
            
        if not label_file.exists():
            print(f"Warning: Label file not found for {patient_id}")
            missing_label.append(patient_id)
            continue
        
        # Add to datalist
        entry = {
            "ct": str(ct_file),
            "pet": str(pet_file),
            "label": str(label_file),
            "patient_id": patient_id,
            "center": center,
        }
        
        datalist.append(entry)
    
    return datalist


def resample_image(image, new_spacing=[1.0, 1.0, 1.0], interpolation=sitk.sitkLinear):
    """Resample image to new spacing."""
    # Get original spacing and size
    original_spacing = image.GetSpacing()
    original_size = image.GetSize()
    
    # Calculate new size
    new_size = [int(round(orig_size * orig_spacing / new_spacing)) 
                for orig_size, orig_spacing, new_spacing in zip(original_size, original_spacing, new_spacing)]
    
    # Create resampling filter
    resampler = sitk.ResampleImageFilter()
    resampler.SetSize(new_size)
    resampler.SetOutputSpacing(new_spacing)
    # Force standard orientation matrix
    resampler.SetOutputDirection([1, 0, 0, 0, 1, 0, 0, 0, 1])
    resampler.SetOutputOrigin(image.GetOrigin())
    resampler.SetTransform(sitk.Transform())
    resampler.SetDefaultPixelValue(0)
    resampler.SetInterpolator(interpolation)
    
    # Execute resampling
    resampled_image = resampler.Execute(image)
    
    return resampled_image


def get_tumor_centered_crop_box(mask_image, crop_size=[200, 200, 310]):
    """
    Calculate a crop box centered on the tumor region from a mask image.
    Returns physical coordinates of the crop box.
    """
    # Convert mask to numpy array for processing
    mask_array = sitk.GetArrayFromImage(mask_image)
    
    # Find tumor voxels (label values > 0)
    tumor_voxels = np.argwhere(mask_array > 0)
    
    if len(tumor_voxels) == 0:
        # If no tumor found, use center of image
        image_size = mask_image.GetSize()
        image_center_idx = [size // 2 for size in image_size]
        
        # Create crop box centered on image center
        physical_center = mask_image.TransformContinuousIndexToPhysicalPoint(image_center_idx)
    else:
        # Calculate centroid of tumor in index coordinates
        # Note: ITK/SITK use [x,y,z] but numpy uses [z,y,x]
        centroid_idx = np.mean(tumor_voxels, axis=0)
        # Convert from [z,y,x] to [x,y,z]
        centroid_idx = np.flip(centroid_idx)
        
        # Convert to physical coordinates
        physical_center = mask_image.TransformContinuousIndexToPhysicalPoint(centroid_idx)
    
    # Calculate physical half_size of crop
    physical_half_size = [size * spacing / 2 for size, spacing in zip(crop_size, mask_image.GetSpacing())]
    
    # Calculate crop box bounds in physical space
    crop_min = [center - half_size for center, half_size in zip(physical_center, physical_half_size)]
    crop_max = [center + half_size for center, half_size in zip(physical_center, physical_half_size)]
    
    return crop_min, crop_max


def crop_image_physical(image, crop_min, crop_max, out_size):
    """
    Crop image using physical coordinates and resample to output size.
    """
    # Create extraction region
    extraction_size = [int(out_size[i]) for i in range(3)]
    
    # Setup the extraction filter
    extract = sitk.RegionOfInterestImageFilter()
    
    # Convert physical bounds to index bounds
    index_min = [int(image.TransformPhysicalPointToIndex(crop_min)[i]) for i in range(3)]
    index_max = [int(image.TransformPhysicalPointToIndex(crop_max)[i]) for i in range(3)]
    
    # Ensure indices are within image bounds
    size = image.GetSize()
    for i in range(3):
        if index_min[i] < 0:
            index_min[i] = 0
        if index_max[i] >= size[i]:
            index_max[i] = size[i] - 1
    
    # Calculate size of region to extract
    region_size = [index_max[i] - index_min[i] for i in range(3)]
    
    # Extract region
    extract.SetSize(region_size)
    extract.SetIndex(index_min)
    cropped = extract.Execute(image)
    
    # If extracted region is smaller than desired size, pad it
    if any(region_size[i] < extraction_size[i] for i in range(3)):
        padded = sitk.ConstantPad(cropped, 
                                  [max(0, extraction_size[i] - region_size[i]) for i in range(3)],
                                  [0, 0, 0], 0)
        return padded
    
    return cropped


def process_patient(patient_data, output_dir, logger=None):
    """Process a single patient's data using SimpleITK."""
    try:
        # Create a copy of the data
        data = dict(patient_data)
        patient_id = data["patient_id"]
        
        # Load images
        ct_image = sitk.ReadImage(data["ct"])
        pet_image = sitk.ReadImage(data["pet"])
        label_image = sitk.ReadImage(data["label"])
        
        # Resample all images to 1x1x1 mm spacing
        # Use B-spline interpolation for CT and PET, nearest neighbor for label
        ct_resampled = resample_image(ct_image, new_spacing=[1.0, 1.0, 1.0], interpolation=sitk.sitkBSpline)
        pet_resampled = resample_image(pet_image, new_spacing=[1.0, 1.0, 1.0], interpolation=sitk.sitkBSpline)
        label_resampled = resample_image(label_image, new_spacing=[1.0, 1.0, 1.0], interpolation=sitk.sitkNearestNeighbor)
        
        # Before cropping, verify tumor coverage
        original_tumor_volume = np.sum(sitk.GetArrayFromImage(label_image) > 0)
        resampled_tumor_volume = np.sum(sitk.GetArrayFromImage(label_resampled) > 0)
        
        # Get crop box coordinates in physical space (centered on tumor)
        crop_min, crop_max = get_tumor_centered_crop_box(label_resampled, crop_size=[200, 200, 310])
        
        # Crop images to the same physical region
        crop_size = [200, 200, 310]  # Target voxel dimensions of crop
        ct_cropped = crop_image_physical(ct_resampled, crop_min, crop_max, crop_size)
        pet_cropped = crop_image_physical(pet_resampled, crop_min, crop_max, crop_size)
        label_cropped = crop_image_physical(label_resampled, crop_min, crop_max, crop_size)
        
        # Check if tumor is preserved in the crop
        cropped_tumor_volume = np.sum(sitk.GetArrayFromImage(label_cropped) > 0)
        
        if cropped_tumor_volume < resampled_tumor_volume:
            tumor_coverage = (cropped_tumor_volume / resampled_tumor_volume) * 100
            message = (
                f"Patient {patient_id}: Tumor is partially cut off by crop. "
                f"Retained {tumor_coverage:.2f}% of tumor voxels. "
                f"Before: {resampled_tumor_volume}, After: {cropped_tumor_volume}"
            )
            print(message)
            if logger:
                logger.warning(message)
        
        # Save processed images
        ct_output_path = os.path.join(output_dir, f"{patient_id}_ct.nii.gz")
        pet_output_path = os.path.join(output_dir, f"{patient_id}_pet.nii.gz")
        label_output_path = os.path.join(output_dir, f"{patient_id}_gt.nii.gz")
        
        sitk.WriteImage(ct_cropped, ct_output_path)
        sitk.WriteImage(pet_cropped, pet_output_path)
        sitk.WriteImage(label_cropped, label_output_path)
        
        print(f"Successfully processed patient {patient_id}")
        return True
    except Exception as e:
        patient_id = patient_data.get("patient_id", "unknown")
        error_msg = f"Error processing patient {patient_id}: {str(e)}"
        print(error_msg)
        if logger:
            logger.error(error_msg)
            import traceback
            logger.error(traceback.format_exc())
        return False


def preprocess_dataset(
    data_dir,
    label_dir,
    output_dir,
    centers=None,
    num_workers=None,
):
    """
    Preprocess the HECKTOR dataset.
    
    Args:
        data_dir: Directory containing CT and PET images
        label_dir: Directory containing label masks
        output_dir: Directory to save preprocessed images
        centers: List of centers to include
        num_workers: Number of workers for parallel processing
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Set up logging
    logger = setup_logging(output_dir)
    logger.info(f"Starting preprocessing for HECKTOR dataset")
    logger.info(f"Data directory: {data_dir}")
    logger.info(f"Label directory: {label_dir}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Centers: {centers if centers else 'all'}")
    
    # Prepare datalist
    print(f"Preparing datalist for centers: {centers if centers else 'all'}")
    datalist = prepare_datalist(
        data_dir=data_dir,
        label_dir=label_dir,
        centers=centers,
    )
    
    logger.info(f"Found {len(datalist)} patients for preprocessing")
    
    # Process the dataset
    print(f"Preprocessing {len(datalist)} patients...")
    
    if num_workers is None or num_workers > 1:
        # Use multiprocessing for faster preprocessing
        if num_workers is None:
            num_workers = mp.cpu_count()
        
        print(f"Using {num_workers} workers for parallel processing")
        logger.info(f"Using {num_workers} workers for parallel processing")
        
        with mp.Pool(processes=num_workers) as pool:
            process_func = partial(process_patient, output_dir=output_dir, logger=logger)
            results = list(tqdm(pool.imap(process_func, datalist), total=len(datalist)))
        
        # Count successful preprocessings
        success_count = sum(results)
        print(f"Successfully preprocessed {success_count}/{len(datalist)} patients")
        logger.info(f"Successfully preprocessed {success_count}/{len(datalist)} patients")
    else:
        # Process sequentially
        success_count = 0
        for patient_data in tqdm(datalist):
            if process_patient(patient_data, output_dir, logger):
                success_count += 1
        
        print(f"Successfully preprocessed {success_count}/{len(datalist)} patients")
        logger.info(f"Successfully preprocessed {success_count}/{len(datalist)} patients")
    
    # Save preprocessing metadata
    metadata = {
        "original_data_dir": str(data_dir),
        "original_label_dir": str(label_dir),
        "preprocessed_data_dir": str(output_dir),
        "centers": centers if centers else "all",
        "total_patients": len(datalist),
        "successfully_preprocessed": success_count,
    }
    
    with open(os.path.join(output_dir, "preprocessing_metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)
    
    print(f"Preprocessing complete. Metadata saved to {os.path.join(output_dir, 'preprocessing_metadata.json')}")
    print(f"Edge cases logged to {os.path.join(output_dir, 'preprocessing_edge_cases.log')}")
    logger.info(f"Preprocessing complete. Edge cases are logged in this file.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Preprocess HECKTOR dataset")
    parser.add_argument("--data_dir", type=str, required=True, help="Directory containing CT and PET images")
    parser.add_argument("--label_dir", type=str, required=True, help="Directory containing label masks")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save preprocessed images")
    parser.add_argument("--centers", type=str, nargs="+", default=None, help="List of centers to include")
    parser.add_argument("--num_workers", type=int, default=None, help="Number of workers for parallel processing")
    
    args = parser.parse_args()
    
    preprocess_dataset(
        data_dir=args.data_dir,
        label_dir=args.label_dir,
        output_dir=args.output_dir,
        centers=args.centers,
        num_workers=args.num_workers,
    ) 