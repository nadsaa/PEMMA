"""
Dataset module for loading and preprocessing 3D medical imaging data for the HECKTOR dataset.
"""

import os
import json
import torch
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union

import monai
from monai.data import CacheDataset, Dataset, PersistentDataset, list_data_collate
from monai.transforms import (
    Compose, 
    LoadImaged, 
    EnsureChannelFirstd, 
    Orientationd, 
    Spacingd, 
    ScaleIntensityd, 
    ScaleIntensityRanged,
    CropForegroundd, 
    RandCropByPosNegLabeld, 
    RandFlipd, 
    RandRotate90d, 
    RandShiftIntensityd, 
    ToTensord,
    ConcatItemsd,
    NormalizeIntensityd,
    RandAffined,
    RandGaussianNoised,
    RandGaussianSmoothd,
    RandScaleIntensityd,
    EnsureTyped,
    Lambdad,
    SpatialPadd
)

# Disable metadata tracking globally for better performance
# monai.data.set_track_meta(False)  # Comment out this line to enable metadata tracking

# Define device for reference but don't use it in transforms
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def sigmoid_activation(x):
    """Apply sigmoid activation to tensor."""
    return torch.sigmoid(x)


def get_transforms(
    mode: str = "train",
    modalities: List[str] = ["ct", "pet"],
    keys: Optional[List[str]] = None,
    spatial_size: Tuple[int, int, int] = (96, 96, 96),
    num_samples: int = 2,
) -> Compose:
    """
    Get transforms for data preprocessing and augmentation for HECKTOR dataset.

    Args:
        mode: One of "train", "val", or "test"
        modalities: List of modalities to use (e.g., ["ct"] or ["ct", "pet"])
        keys: Keys for the data dictionary. If None, set to modalities + ["label"]
        spatial_size: Spatial size for cropping
        num_samples: Number of samples for random crop (training only)

    Returns:
        Composed transforms
    """
    if keys is None:
        keys = modalities + ["label"]
    image_keys = [k for k in keys if k != "label"]
    label_key = "label"
    concat_transform = ConcatItemsd(keys=image_keys, name="image", dim=0)

    if mode == "train":
        transforms = Compose(
            [
                # Load and ensure channel first in one step
                LoadImaged(keys=keys, ensure_channel_first=True),
                SpatialPadd(
                    keys=keys,
                    spatial_size=[200, 200, 310],
                    mode="constant",
                    constant_values=0,
                ),
                
                # Intensity preprocessing
                *([
                    ScaleIntensityRanged(
                        keys=["ct"],
                        a_min=-200,
                        a_max=250,
                        b_min=0.0,
                        b_max=1.0,
                        clip=True,
                    ),
                    # CT-specific intensity augmentations
                    RandScaleIntensityd(keys=["ct"], factors=0.1, prob=0.5),
                    RandShiftIntensityd(keys=["ct"], offsets=0.1, prob=0.5),
                    RandGaussianNoised(keys=["ct"], std=0.01, prob=0.2),
                    # Removed sigmoid activation
                ] if "ct" in modalities else []),
                *([
                    NormalizeIntensityd(keys=["pet"], nonzero=True),
                    # Removed sigmoid activation
                ] if "pet" in modalities else []),
                
                
                # Concatenate modalities
                concat_transform,
                
                # Orient to RAS
                Orientationd(keys=["image", label_key], axcodes="RAS"),
                
                # Random crop around ROI
                RandCropByPosNegLabeld(
                    keys=["image", label_key],
                    label_key=label_key,
                    spatial_size=spatial_size,
                    pos=2,
                    neg=1,
                    num_samples=num_samples,
                    image_key="image",
                    image_threshold=0,
                ),
                
                # Spatial augmentations
                RandAffined(
                    keys=["image", label_key],
                    prob=0.5,
                    rotate_range=(np.pi/20, np.pi/20, np.pi/20),  # ±9°
                    scale_range=(0.1, 0.1, 0.1),  # ±10%
                    mode=("bilinear", "nearest"),
                    padding_mode="zeros",
                ),
                RandFlipd(keys=["image", label_key], spatial_axis=[0, 1, 2], prob=0.2),
                RandRotate90d(keys=["image", label_key], max_k=3, prob=0.2),
                
                # Removing the intensity augmentations here since they're now applied to CT channel before concatenation
                
                # Final type conversion
                EnsureTyped(keys=["image", label_key]),
            ]
        )
    else:  # "val" or "test"
        transforms = Compose(
            [
                LoadImaged(keys=keys, ensure_channel_first=True),
                SpatialPadd(
                    keys=keys,
                    spatial_size=[200, 200, 310],
                    mode="constant",
                    constant_values=0,
                ),
                *([
                    ScaleIntensityRanged(
                        keys=["ct"],
                        a_min=-200,
                        a_max=250,
                        b_min=0.0,
                        b_max=1.0,
                        clip=True,
                    ),
                    # No intensity augmentations for validation/test
                    # Removed sigmoid activation
                ] if "ct" in modalities else []),
                *([
                    NormalizeIntensityd(keys=["pet"], nonzero=True),
                    # Removed sigmoid activation
                ] if "pet" in modalities else []),
               
                concat_transform,
                Orientationd(keys=["image", label_key], axcodes="RAS"),
                EnsureTyped(keys=["image", label_key]),
            ]
        )
    return transforms


def get_dataset(
    data_dir: Union[str, Path],
    datalist: List[Dict],
    mode: str = "train",
    modalities: List[str] = ["ct", "pet"],
    cache_rate: float = 1.0,
    num_workers: int = 4,
    persistent_cache: bool = False,
    cache_dir: Optional[Union[str, Path]] = None,
    num_samples: int = 4,
) -> Union[Dataset, CacheDataset, PersistentDataset]:
    """
    Get dataset for training, validation, or testing.
    
    Args:
        data_dir: Base data directory
        datalist: List of data dictionaries with paths
        mode: One of "train", "val", or "test"
        modalities: List of modalities to use (e.g., ["ct"] or ["ct", "pet"])
        cache_rate: Cache rate for CacheDataset
        num_workers: Number of workers for data loading
        persistent_cache: Whether to use PersistentDataset
        cache_dir: Directory for persistent cache
        num_samples: Number of samples for random crop (only used in training)
        
    Returns:
        Dataset object
    """
    transforms = get_transforms(mode=mode, modalities=modalities, num_samples=num_samples)
    
    if persistent_cache and cache_dir is not None:
        os.makedirs(cache_dir, exist_ok=True)
        dataset = PersistentDataset(
            data=datalist,
            transform=transforms,
            cache_dir=cache_dir,
        )
    elif cache_rate > 0.0:
        # For distributed training, it's better to use copy_cache=True
        dataset = CacheDataset(
            data=datalist,
            transform=transforms,
            cache_rate=cache_rate,
            num_workers=num_workers,
            copy_cache=True,  # Make a copy for each worker to prevent sharing issues
        )
    else:
        dataset = Dataset(
            data=datalist,
            transform=transforms,
        )
    
    return dataset


def prepare_datalist(
    data_dir: Union[str, Path],
    centers: List[str],
    modalities: List[str] = ["ct", "pet"],
    train_ratio: float = 0.8,
    val_ratio: float = 0.2,
    seed: int = 42,
) -> Dict[str, List[Dict]]:
    """
    Prepare datalist for dataset creation from the HECKTOR dataset.
    
    Args:
        data_dir: Base data directory containing the HECKTOR dataset
        centers: List of centers to include
        modalities: List of modalities to use (e.g., ["ct"] or ["ct", "pet"])
        train_ratio: Ratio of data to use for training
        val_ratio: Ratio of data to use for validation
        seed: Random seed for reproducibility
        
    Returns:
        Dictionary with train and val datalists
    """
    data_dir = Path(data_dir)
    
    # Get all CT files (we use CT as the base for finding patients)
    ct_files = sorted(list(data_dir.glob("*_ct.nii.gz")))
    
    # Create datalist entries
    datalist = []
    for ct_file in ct_files:
        # Extract patient ID
        patient_id = ct_file.stem.split("_")[0]
        
        # Extract center
        center = patient_id.split("-")[0]
        
        # Skip if center not in centers list
        if center not in centers:
            continue
        
        # Check if all required modality files exist
        modality_files = {}
        all_files_exist = True
        
        for modality in modalities:
            modality_file = data_dir / f"{patient_id}_{modality}.nii.gz"
            if not modality_file.exists():
                all_files_exist = False
                break
            modality_files[modality] = str(modality_file)
        
        # Get ground truth file
        gt_file = data_dir / f"{patient_id}_gt.nii.gz"
        if not gt_file.exists():
            all_files_exist = False
        
        # Add to datalist if all files exist
        if all_files_exist:
            entry = {
                "label": str(gt_file),
                "patient_id": patient_id,
                "center": center,
            }
            # Add modality files
            for modality in modalities:
                entry[modality] = modality_files[modality]
            
            datalist.append(entry)
    
    # Set random seed for reproducibility
    np.random.seed(seed)
    
    # Shuffle the datalist
    indices = np.arange(len(datalist))
    np.random.shuffle(indices)
    
    # Calculate split sizes
    train_size = int(len(datalist) * train_ratio)
    
    # Split the datalist
    train_indices = indices[:train_size]
    val_indices = indices[train_size:]
    
    # Create split datalists
    train_datalist = [datalist[i] for i in train_indices]
    val_datalist = [datalist[i] for i in val_indices]
    
    return {
        "train": train_datalist,
        "val": val_datalist,
    }


def prepare_cross_validation_datalist(
    data_dir: Union[str, Path],
    centers: List[str],
    modalities: List[str] = ["ct", "pet"],
    num_folds: int = 5,
    seed: int = 42,
) -> List[Dict[str, List[Dict]]]:
    """
    Prepare datalist for cross-validation.
    
    Args:
        data_dir: Base data directory containing the HECKTOR dataset
        centers: List of centers to include
        modalities: List of modalities to use (e.g., ["ct"] or ["ct", "pet"])
        num_folds: Number of folds for cross-validation
        seed: Random seed for reproducibility
        
    Returns:
        List of dictionaries with train and val datalists for each fold
    """
    data_dir = Path(data_dir)
    
    # Get all CT files (we use CT as the base for finding patients)
    ct_files = sorted(list(data_dir.glob("*_ct.nii.gz")))
    
    # Create datalist entries
    datalist = []
    for ct_file in ct_files:
        # Extract patient ID
        patient_id = ct_file.stem.split("_")[0]
        
        # Extract center
        center = patient_id.split("-")[0]
        
        # Skip if center not in centers list
        if center not in centers:
            continue
        
        # Check if all required modality files exist
        modality_files = {}
        all_files_exist = True
        
        for modality in modalities:
            modality_file = data_dir / f"{patient_id}_{modality}.nii.gz"
            if not modality_file.exists():
                all_files_exist = False
                break
            modality_files[modality] = str(modality_file)
        
        # Get ground truth file
        gt_file = data_dir / f"{patient_id}_gt.nii.gz"
        if not gt_file.exists():
            all_files_exist = False
        
        # Add to datalist if all files exist
        if all_files_exist:
            entry = {
                "label": str(gt_file),
                "patient_id": patient_id,
                "center": center,
            }
            # Add modality files
            for modality in modalities:
                entry[modality] = modality_files[modality]
            
            datalist.append(entry)
    
    # Set random seed for reproducibility
    np.random.seed(seed)
    
    # Shuffle the datalist
    indices = np.arange(len(datalist))
    np.random.shuffle(indices)
    
    # Create folds
    fold_size = len(datalist) // num_folds
    folds = []
    
    for fold in range(num_folds):
        # Calculate start and end indices for validation set
        val_start = fold * fold_size
        val_end = (fold + 1) * fold_size if fold < num_folds - 1 else len(datalist)
        
        # Get validation indices for this fold
        val_indices = indices[val_start:val_end]
        
        # Get training indices for this fold (all indices except validation)
        train_indices = np.array([i for i in indices if i not in val_indices])
        
        # Create train and val datalists for this fold
        train_datalist = [datalist[i] for i in train_indices]
        val_datalist = [datalist[i] for i in val_indices]
        
        # Add to folds
        folds.append({
            "train": train_datalist,
            "val": val_datalist,
        })
    
    return folds


def get_dataloader(
    dataset: Union[Dataset, CacheDataset, PersistentDataset],
    batch_size: int = 2,
    shuffle: bool = True,
    num_workers: int = 4,
    pin_memory: bool = True,
    sampler: Optional[torch.utils.data.Sampler] = None,
) -> torch.utils.data.DataLoader:
    """
    Get dataloader for the dataset.
    
    Args:
        dataset: Dataset object
        batch_size: Batch size
        shuffle: Whether to shuffle the data
        num_workers: Number of workers for data loading
        pin_memory: Whether to use pin_memory
        sampler: Optional sampler for the data
        
    Returns:
        DataLoader object
    """
    return torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle if sampler is None else False,  # Don't shuffle if using a sampler
        num_workers=num_workers,
        pin_memory=pin_memory,
        sampler=sampler,
        collate_fn=list_data_collate,
    )


def get_center_statistics(data_dir: Union[str, Path]) -> pd.DataFrame:
    """
    Get statistics about the centers in the HECKTOR dataset.
    
    Args:
        data_dir: Base data directory containing the HECKTOR dataset
        
    Returns:
        DataFrame with center statistics
    """
    data_dir = Path(data_dir)
    
    # Get all CT files
    ct_files = sorted(list(data_dir.glob("*_ct.nii.gz")))
    
    # Extract centers
    centers = [ct_file.stem.split("_")[0].split("-")[0] for ct_file in ct_files]
    
    # Count patients per center
    center_counts = pd.Series(centers).value_counts().reset_index()
    center_counts.columns = ["Center", "Patient Count"]
    
    return center_counts


def load_strategy_config(config_path: Union[str, Path]) -> Dict:
    """
    Load the training strategy configuration from a JSON file.
    
    Args:
        config_path: Path to the JSON configuration file
        
    Returns:
        Dictionary containing the training strategy configuration
    """
    with open(config_path, 'r') as f:
        config = json.load(f)
    return config


def get_phase_dataloaders(
    data_dir: Union[str, Path],
    config_path: Union[str, Path],
    phase: str,
    batch_size: int = 2,
    num_workers: int = 4,
    cache_rate: float = 1.0,
    persistent_cache: bool = False,
    cache_dir: Optional[Union[str, Path]] = None,
    seed: int = 42,
    num_samples: int = 4,
) -> Dict[str, torch.utils.data.DataLoader]:
    """
    Get dataloaders for a specific phase of the training strategy.
    
    Args:
        data_dir: Base data directory containing the HECKTOR dataset
        config_path: Path to the JSON configuration file
        phase: Phase of the training strategy (e.g., "pretraining", "multimodal_adaptation")
        batch_size: Batch size for the dataloaders
        num_workers: Number of workers for data loading
        cache_rate: Cache rate for CacheDataset
        persistent_cache: Whether to use PersistentDataset
        cache_dir: Directory for persistent cache
        seed: Random seed for reproducibility
        num_samples: Number of samples for random crop (only used in training)
        
    Returns:
        Dictionary with train and val dataloaders
    """
    # Load the strategy configuration
    config = load_strategy_config(config_path)
    
    # Check if the phase exists in the configuration
    if phase not in config["phases"]:
        raise ValueError(f"Phase '{phase}' not found in the configuration")
    
    # Get the phase configuration
    phase_config = config["phases"][phase]
    
    # Prepare the datalist using provided seed for data splitting
    datalist_dict = prepare_datalist(
        data_dir=data_dir,
        centers=phase_config["centers"],
        modalities=phase_config["modalities"],
        train_ratio=phase_config["train_ratio"],
        val_ratio=phase_config["val_ratio"],
        seed=seed,  # Use the provided seed for data splitting - different seeds = different splits
    )
    
    # Create datasets
    train_dataset = get_dataset(
        data_dir=data_dir,
        datalist=datalist_dict["train"],
        mode="train",
        modalities=phase_config["modalities"],
        cache_rate=cache_rate,
        num_workers=num_workers,
        persistent_cache=persistent_cache,
        cache_dir=cache_dir,
        num_samples=num_samples,
    )
    
    val_dataset = get_dataset(
        data_dir=data_dir,
        datalist=datalist_dict["val"],
        mode="val",
        modalities=phase_config["modalities"],
        cache_rate=cache_rate,
        num_workers=num_workers,
        persistent_cache=persistent_cache,
        cache_dir=cache_dir,
        num_samples=num_samples,
    )
    
    # Create dataloaders
    train_dataloader = get_dataloader(
        dataset=train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
    )
    
    val_dataloader = get_dataloader(
        dataset=val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    
    return {
        "train": train_dataloader,
        "val": val_dataloader,
    }


def verify_strategy_config(config_path: Union[str, Path], data_dir: Union[str, Path]) -> Dict:
    """
    Verify that the training strategy configuration matches the actual data.
    
    Args:
        config_path: Path to the JSON configuration file
        data_dir: Base data directory containing the HECKTOR dataset
        
    Returns:
        Dictionary with verification results
    """
    # Load the strategy configuration
    config = load_strategy_config(config_path)
    
    # Get center statistics
    center_stats = get_center_statistics(data_dir)
    
    # Create a dictionary to store verification results
    verification = {
        "phases": {},
        "centers": {},
        "overall": True,
    }
    
    # Verify center counts
    for center, details in config["center_details"].items():
        expected_count = details["total_samples"]
        actual_count = center_stats[center_stats["Center"] == center]["Patient Count"].values
        
        if len(actual_count) == 0:
            actual_count = 0
        else:
            actual_count = actual_count[0]
        
        verification["centers"][center] = {
            "expected": expected_count,
            "actual": actual_count,
            "match": expected_count == actual_count,
        }
        
        if expected_count != actual_count:
            verification["overall"] = False
    
    # Verify phase splits
    for phase, phase_config in config["phases"].items():
        # Prepare the datalist
        datalist_dict = prepare_datalist(
            data_dir=data_dir,
            centers=phase_config["centers"],
            modalities=phase_config["modalities"],
            train_ratio=phase_config["train_ratio"],
            val_ratio=phase_config["val_ratio"],
            seed=42,
        )
        
        # Get actual counts
        actual_train_count = len(datalist_dict["train"])
        actual_val_count = len(datalist_dict["val"])
        
        # Get expected counts
        expected_train_count = config["expected_splits"][phase]["train"]
        expected_val_count = config["expected_splits"][phase]["val"]
        
        verification["phases"][phase] = {
            "train": {
                "expected": expected_train_count,
                "actual": actual_train_count,
                "match": expected_train_count == actual_train_count,
            },
            "val": {
                "expected": expected_val_count,
                "actual": actual_val_count,
                "match": expected_val_count == actual_val_count,
            },
        }
        
        if expected_train_count != actual_train_count or expected_val_count != actual_val_count:
            verification["overall"] = False
    
    return verification 